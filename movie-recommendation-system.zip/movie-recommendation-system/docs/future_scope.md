# Future Scope

The following extensions would be technically relevant next steps building on this
project's foundation. Each is scoped to what would genuinely improve on the current,
honestly-evaluated baseline (Item-Based CF, Precision@10=0.099) rather than generic
buzzword additions.

## 1. Deep Learning Recommenders
**Neural Collaborative Filtering (NCF)**: replace the linear dot-product interaction in
SVD with a learned neural interaction function (MLP over user/item embeddings). Would be
worth benchmarking against this project's SVD RMSE (0.890) on the same test split, since
NCF's main advantage — capturing non-linear interactions — is only valuable if it actually
beats the simpler linear baseline on this dataset's scale (1M ratings is small for deep
learning; risk of overfitting is real and should be checked, not assumed away).

## 2. Sequence/Session-Based Recommendation
This project treats each rating independently; a **session-based model** (e.g. GRU4Rec-style
recurrent architecture, or a Transformer-based sequential recommender) would use the
`timestamp` field (currently only used for the temporal train/test split) to model
*order* of consumption — relevant since MovieLens 1M ratings do carry real timestamps that
this project's current algorithms otherwise ignore for ranking.

## 3. Context-Aware Recommendation
Incorporating context signals (time of day, day of week, device) that this dataset does
not contain but a production system would collect — would require new data collection,
not just new modeling, so this is future-scope rather than an oversight in this project.

## 4. Real-Time / Online Recommendation
Current models are trained offline and served via cached, static artifacts (see
`docs/technical_documentation.md`). A production system would need an online-learning or
frequent-retraining pipeline to incorporate new ratings without a full offline retrain —
relevant given this project's own EDA showing power users can generate hundreds of new
ratings that would otherwise sit stale between retrains.

## 5. Explainable Recommendations
Item-Based CF's `similar_items()` output (Phase 12) already provides a natural
explanation surface ("recommended because you liked X") that this project's Streamlit app
does not yet expose to the end user — a concrete, low-effort next step using data already
computed.

## 6. Reinforcement Learning for Ranking
Framing recommendation as a bandit/RL problem (optimizing for long-term engagement rather
than single-step rating prediction) is a natural extension once real user feedback/reward
signal exists — not meaningful to prototype on this static offline dataset, which has no
notion of sequential reward.

## 7. MLOps: Continuous Evaluation and Retraining
This project's evaluation pipeline (`src/evaluation.py`) is already structured to score
any `recommend_fn(user_id) -> List[item_id]`, which makes it a reasonable foundation for
an automated CI evaluation gate (e.g., block a model deployment if Precision@10 regresses
below the current 0.099 baseline) — a natural next engineering step.

## 8. Online A/B Testing Infrastructure
The single largest gap between this project's offline metrics and real business impact
(see `docs/business_documentation.md` — Business Limitations) is the absence of live
traffic. A/B testing infrastructure to compare the Item-Based CF model against a
popularity-only control on real users would be the necessary next step to convert this
project's offline findings into validated business KPIs (CTR, conversion, retention).

## 9. Fairness and Bias Auditing
This project deliberately excluded demographic features from ranking-model inputs as a
precaution (see `data/README.md`), but did not run a formal fairness audit (e.g.,
per-demographic-group Precision@K breakdown) — a natural and important extension before
any production deployment.

## 10. Diversity-Aware Re-ranking
Given the honest finding that Item-Based CF has lower Coverage/Diversity than SVD
(`reports/system_metrics.json`), a natural next step is a re-ranking layer (e.g.
Maximal Marginal Relevance) applied on top of Item-Based CF's ranked list to trade a small
amount of precision for materially better catalog coverage — combining the accuracy
strength of the selected model with the discovery strength observed in SVD.
