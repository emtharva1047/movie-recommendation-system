# Resume Bullet Points

ATS-friendly bullets describing this project, generated only from work actually completed
and verified in this repository. No percentages, metrics, or outcomes are invented — every
number below is traceable to `reports/model_comparison_FINAL.csv`,
`reports/system_metrics.json`, or the test suite's own output.

## Project Title
**Recommendation System using Machine Learning — MovieLens 1M** (Personal / Academic Project)

## Resume Bullets (choose based on target role and space available)

- Designed and implemented an end-to-end recommendation system in Python on the MovieLens
  1M dataset (1M+ ratings, 6,040 users, 3,883 items), building six distinct algorithms —
  Popularity Baseline, Content-Based Filtering (TF-IDF), User-Based and Item-Based
  Collaborative Filtering, SVD Matrix Factorization, and a Hybrid model — sharing a common,
  testable interface.

- Engineered a fair, leakage-checked evaluation framework using a temporal per-user
  train/test split (verified zero leakage violations across 197,510 held-out ratings) and
  seven ranking/prediction/system-level metrics (Precision@K, Recall@K, MAP@K, NDCG@K,
  RMSE, MAE, Coverage, Diversity, Novelty); selected the production model based on measured
  results, achieving a 2.5× Precision@10 improvement over a popularity-based baseline.

- Identified and fixed a data-integrity defect in an iterative preprocessing pipeline via a
  self-authored automated test suite (52 pytest tests, 100% passing), re-validating the
  entire downstream pipeline (feature engineering, model training, evaluation) after the fix
  to maintain full cross-artifact consistency.

- Built and deployed an interactive Streamlit web application exposing personalized
  recommendations, item-similarity search, catalog search, and live model comparison;
  validated end-to-end using headless server startup checks and automated browser testing
  (Playwright/Chromium).

- Authored complete technical documentation for the project, including an installation
  guide, architecture documentation, business-impact analysis (explicitly separating
  measured findings from industry-standard hypotheses), and a 50+ question technical
  interview preparation guide.

- Produced a 24-page technical report and a 30-slide presentation with speaker notes,
  programmatically generated with embedded real data visualizations, screenshots, and
  metrics tables, cross-validated for internal consistency across every deliverable.

## Skills Demonstrated (for a Skills section)
Python (pandas, NumPy, SciPy, scikit-learn), collaborative filtering, content-based
filtering, matrix factorization (SVD), TF-IDF and cosine similarity, sparse matrix
computation, recommender-system evaluation metrics, Streamlit, pytest, data pipeline
design, technical documentation, reproducible ML engineering (fixed seeds, centralized
configuration, automated testing).

## Notes on Honest Framing
- No claim of "production deployment" beyond an actually-validated local Streamlit app is
  made — the resume language above says "deployed an interactive Streamlit web
  application," which is accurate to what was built and tested, not "deployed to
  production" or "serving live users," which would be false.
- No business-impact percentage (e.g., "increased engagement by X%") is included anywhere,
  since this project has no live traffic data to support such a claim — consistent with the
  project's own explicit rule against fabricated business metrics.
