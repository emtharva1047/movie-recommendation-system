# Installation Guide

## Prerequisites
- **Python 3.12** (this project was built and validated on Python 3.12.3; Python 3.10+
  should work but has not been tested here)
- ~200 MB disk space (dataset + processed artifacts + trained models)
- No GPU required

## 1. Clone the Repository
```bash
git clone <repository-url>
cd Recommendation-System
```

## 2. Create a Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate        # Linux/macOS
venv\Scripts\activate           # Windows
```

## 3. Install Dependencies
```bash
pip install -r requirements.txt
```
All versions in `requirements.txt` are pinned to what this project was actually built and
tested against.

## 4. Dataset Setup

The raw MovieLens 1M files are included under `data/raw/` (`ratings.dat`, `movies.dat`,
`users.dat`, plus the official `README`). If you need to re-download them:

- Official source: https://grouplens.org/datasets/movielens/1m/
- This project's files were sourced from a verified GitHub mirror
  (`raw.githubusercontent.com/ChicagoBoothML/DATA___MovieLens___1M`) because the official
  `files.grouplens.org` host was not reachable from the original build environment's
  network policy. Row counts were verified against the official README
  (1,000,209 ratings / 3,883 movies / 6,040 users) before use.

No manual setup is required if `data/raw/*.dat` files are already present (they are
included in this repository / ZIP package).

## 5. Reproduce the Processed Data and Models

Run in order:
```bash
python -m src.preprocessing         # -> data/processed/{ratings,movies,users}_clean.csv
python -m src.feature_engineering   # -> data/processed/{user,item}_features.csv
python -m src.train_test_split      # -> data/processed/{train,test}_ratings.csv
```
Each script prints and logs its own validation output (row counts, leakage checks).
Model training scripts are provided as notebook cells in `notebooks/06_recommendation_models.ipynb`
and can be run end-to-end with:
```bash
jupyter nbconvert --to notebook --execute notebooks/06_recommendation_models.ipynb
```

## 6. Run the Notebooks
```bash
pip install jupyter          # if not already installed
python -m ipykernel install --user --name python3 --display-name "Python 3"
jupyter notebook notebooks/
```
Open notebooks `01` through `08` in order.

## 7. Run the Tests
```bash
pytest tests/ -v
```
Expected: 52 tests, all passing (verified at project completion time).

## 8. Launch the Streamlit Application
```bash
streamlit run app.py
```
This opens the app at `http://localhost:8501` by default. Use the sidebar to navigate
between Home/Dashboard, Get Recommendations, Similar Movies, Search Movies, and Model
Comparison.

## Troubleshooting

| Issue | Fix |
|---|---|
| `ModuleNotFoundError: No module named 'src'` | Run commands from the project root directory (`Recommendation-System/`), not from inside `src/` |
| `FileNotFoundError` for a `.dat` file | Ensure `data/raw/` contains `ratings.dat`, `movies.dat`, `users.dat` — see step 4 |
| `FileNotFoundError` for a `_clean.csv` file | Run step 5's scripts in order first |
| Streamlit app shows "model file not found" | Ensure `models/trained_models/*.pkl` exist — regenerate via `notebooks/06` if missing |
| `pip install scikit-surprise` fails | Requires a C compiler; on Debian/Ubuntu run `apt-get install build-essential` first |
