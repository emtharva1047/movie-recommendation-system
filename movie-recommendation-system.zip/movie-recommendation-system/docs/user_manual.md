# User Manual — Streamlit Application

## Starting the App
```bash
streamlit run app.py
```
Open the printed local URL (typically `http://localhost:8501`) in your browser.

## Navigation
Use the sidebar radio buttons to move between five pages:

### 1. Home / Dashboard
Shows dataset summary statistics (total ratings, users, movies, matrix sparsity), the
selected production model and why it was chosen, the full model comparison table (real
metrics, loaded from `reports/model_comparison_final.json`), and a genre-distribution
chart of the catalog.

### 2. Get Recommendations
1. Choose how to select a user: pick from a dropdown list, or type a User ID directly.
2. Choose the number of recommendations (5–20).
3. Choose the recommendation method (Item-Based CF is recommended and pre-selected as the
   best-evaluated option; Popularity Baseline is available for comparison).
4. Click **Generate Recommendations**.
5. The app shows the user's top-rated history (for context) and the generated Top-N
   recommendation list with scores.
6. Click **Download Recommendations as CSV** to export the result.

**Error handling**: entering a User ID that doesn't exist in the training data shows a
clear error message with the valid ID range — the app does not crash.

### 3. Similar Movies
1. Select any movie from the searchable dropdown.
2. Choose how many similar movies to show.
3. Click **Find Similar Movies** to see a ranked list with similarity scores, computed via
   Item-Based Collaborative Filtering (co-rating pattern similarity, not just genre).

**Error handling**: a movie with too few ratings to compute reliable similarity shows a
warning message rather than an empty or broken table.

### 4. Search Movies
Search the full movie catalog by title keyword and/or filter by one or more genres. Results
update live as you type/select. If nothing matches, a clear "no results" message is shown.

### 5. Model Comparison
Displays the full evaluation table (Precision@10, Recall@10, MAP@10, NDCG@10, RMSE, MAE)
for every implemented algorithm, evaluated on the identical held-out sample, plus a bar
chart and a short written explanation of why Item-Based CF was selected as the production
model.

## Tips
- The first page load may take a few seconds while models and data are cached
  (`st.cache_resource` / `st.cache_data`) — this only happens once per server session, not
  on every interaction.
- If you see "model file not found," the trained model artifacts under
  `models/trained_models/` are missing — see `docs/installation_guide.md` step 5 to
  regenerate them.
