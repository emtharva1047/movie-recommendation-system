# Project Architecture

## Directory Layout and Purpose

```
Recommendation-System/
│
├── data/
│   ├── raw/                  # Unmodified MovieLens 1M source files (.dat) + official README
│   ├── processed/            # Cleaned CSVs, sparse matrices, ID mappings, train/test splits
│   └── README.md             # Data dictionary, license, source documentation
│
├── notebooks/                # 8 executable notebooks, one per pipeline stage (01-08)
│                              # Each calls into src/ modules rather than duplicating logic
│
├── src/                      # Production source code (PEP-8, typed, tested)
│   ├── config.py             # Single source of truth: paths, seeds, hyperparameters, thresholds
│   ├── logging_config.py     # Centralized logging setup
│   ├── data_loader.py        # Raw .dat file parsing with validation
│   ├── preprocessing.py      # Iterative-convergence cleaning pipeline
│   ├── feature_engineering.py # User/item feature derivation (leakage-checked)
│   ├── train_test_split.py   # Temporal per-user split + leakage self-check
│   ├── recommender.py        # All 6 algorithm implementations (shared interface)
│   └── evaluation.py         # Ranking, prediction, and system-level metrics
│
├── models/trained_models/    # Serialized (pickle) trained model artifacts
│
├── reports/                  # Generated metrics (JSON/CSV), insights (Markdown), the
│   └── figures/                20-30 page report, and evaluation artifacts
│
├── figures/                  # 12 EDA visualizations (PNG)
├── screenshots/               # 6 real, browser-captured Streamlit app screenshots
│
├── deployment/                # Deployment-specific requirements/notes
├── tests/                    # 39 pytest unit tests across data, models, evaluation
├── docs/                     # README, installation guide, technical/business docs,
│                              # user manual, future scope
│
├── app.py                    # Streamlit application (production entry point)
├── requirements.txt
├── README.md
├── LICENSE
├── .gitignore
└── PROJECT_MANIFEST.md
```

## Why This Structure

**Separation of `src/` from `notebooks/`**: Notebooks are for exploration, narrative, and
demonstration; `src/` holds the tested, reusable, importable logic. Every notebook imports
from `src/` rather than re-implementing anything, which guarantees the notebooks, the
Streamlit app, and the automated tests all exercise the exact same code path — there is
no risk of the notebook silently drifting from what's actually deployed.

**`data/raw/` vs `data/processed/`**: Raw files are treated as immutable/read-only inputs
(never edited in place); all cleaning output goes to `processed/`, which is fully
reproducible from `raw/` by re-running `python -m src.preprocessing`.

**`config.py` as single source of truth**: Cleaning thresholds, random seed, split ratio,
and model hyperparameters are defined once and imported everywhere. This is what makes the
"cross-document consistency" requirement achievable — if a threshold changes, it changes in
exactly one place and every downstream artifact (notebooks, app, tests) picks it up.

## Data Flow (Pipeline Order)

```
raw/*.dat
   │  src/data_loader.py
   ▼
DataFrames (validated columns/types)
   │  src/preprocessing.py  (iterative dual-threshold filtering)
   ▼
data/processed/*_clean.csv
   │  src/feature_engineering.py          src/train_test_split.py
   ▼                                              ▼
user_features.csv, item_features.csv    train_ratings.csv, test_ratings.csv
   │                                              │
   └──────────────────┬───────────────────────────┘
                       ▼
              src/recommender.py (6 algorithms trained on train_ratings.csv)
                       │
                       ▼
              models/trained_models/*.pkl
                       │
        ┌──────────────┼──────────────────┐
        ▼               ▼                  ▼
 src/evaluation.py   app.py           notebooks/08
 (scored vs test)   (Streamlit)     (sample outputs)
```

## Deployment Architecture (Streamlit)

`app.py` loads pre-trained model artifacts from `models/trained_models/` via
`st.cache_resource` (loaded once per server process, not per request) and cleaned data via
`st.cache_data`. No model training happens at request time — this is standard practice for
keeping inference latency low and avoiding redundant computation on every page interaction.
The app is stateless beyond Streamlit's own session state; horizontal scaling would only
require replicating the process, since there is no server-side write path.
