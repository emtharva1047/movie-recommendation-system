# Business Documentation

## Business Problem
Platforms with large content catalogs (movies, products, music) face a discovery problem:
without personalization, every user is shown the same generic listing, which under-serves
individual taste, under-exposes the long tail of the catalog, and leaves engagement and
cross-sell/upsell opportunity on the table.

## Stakeholders
| Stakeholder | Interest |
|---|---|
| Product/Business team | Engagement, conversion, revenue (hypothesized outcomes of better recommendations) |
| Data Science/ML team | Model accuracy, ranking quality, maintainability, reproducibility |
| Engineering/MLOps | Latency, scalability, deployment reliability |
| End users | Relevant, diverse, trustworthy recommendations; not a filter bubble |

## KPIs

### Technical KPIs (measured in this project, on real held-out data)
- Precision@10, Recall@10, MAP@10, NDCG@10 — ranking quality
- RMSE, MAE — rating-prediction accuracy (where applicable, i.e. SVD)
- Coverage, Diversity, Novelty — system-level health (catches popularity-bias failure modes)

### Business KPIs (industry-standard hypotheses — NOT measured by this project)
- Click-through rate (CTR) on recommended items
- Conversion rate attributable to recommendations
- Average Order Value (AOV) uplift
- Retention / churn rate change

**This project reports only the technical KPIs.** No live traffic or transaction data
exists in this academic dataset, so no business-KPI number is claimed anywhere in this
project's deliverables. Business Hypotheses are clearly labeled as such throughout
`reports/business_insights.md`.

## Recommendation Strategy
The selected production model — **Item-Based Collaborative Filtering** — was chosen
because it achieved the best ranking accuracy of every algorithm tested, on an identical
held-out evaluation sample (see `reports/model_comparison_FINAL.csv`). This is a
data-driven selection, not an assumption: the popularity baseline, content-based, both
user-based CF variants, SVD, and a hybrid blend were all implemented, trained, and
evaluated under the same conditions before this choice was made.

## Business Insights (Summary)
Full detail with observed-vs-hypothesis labeling: `reports/business_insights.md`. Headline
findings:
1. Personalized (Item-Based CF) ranking is ~2.5x more precise than a "most popular" rail
   on this dataset's held-out data.
2. A pure popularity strategy would expose users to under 1% of the catalog; Item-Based CF
   reaches ~7.85%, SVD reaches ~21.5% — a genuine accuracy-vs-discovery trade-off worth a
   product decision, not an oversight.
3. Item-Based CF's similar-item output is coherent and immediately usable for cross-sell
   placements (e.g., "similar to this" rails).
4. Cold-start users (≤5 ratings) are handled via automatic fallback to the popularity
   signal in the Hybrid model design, though the pure Hybrid did not outperform Item-Based
   CF in this specific offline evaluation — an honest finding, not adjusted after the fact.

## Potential Applications
- Movie/TV streaming platform "Recommended for You" rail
- E-commerce "customers who liked this also liked" cross-sell placement
- Any catalog-based platform (books, music, courses) with explicit or implicit rating data

## Business Limitations
- Offline evaluation cannot measure actual business outcomes (CTR, conversion, revenue) —
  a live A/B test would be required before making resourcing decisions based on this work.
- The dataset is from 2000–2003; user taste distributions and catalog composition on a
  modern platform would differ.
- Demographic features (age/gender/occupation) were deliberately excluded from the ranking
  models to avoid majority-demographic bias — this is a fairness-conscious design choice,
  documented in `data/README.md`, and should be revisited with real product fairness
  requirements before production use.

## Future Business Opportunities
See `docs/future_scope.md` for the technical roadmap (deep learning recommenders, session-based
recommendations, A/B testing infrastructure) that would be required to validate and extend
these offline findings into measurable business impact.
