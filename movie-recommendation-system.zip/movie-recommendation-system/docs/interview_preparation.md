# Interview Preparation — Recommendation Systems

50+ questions with complete answers, explanations, practical examples, and likely
follow-ups, organized by topic. Every numerical answer below is drawn directly from this
project's own computed results (`reports/model_comparison_FINAL.csv`,
`reports/system_metrics.json`) — not generic textbook numbers.

---

## A. Recommendation Fundamentals

**1. What is a recommendation system?**
A filtering system that predicts which items a specific user is likely to prefer, using
historical interactions and/or item attributes, and ranks a subset of the catalog for that
user instead of showing everyone the same list.
*Follow-up*: "What's the difference between a recommendation system and a search engine?"
Search is query-driven and explicit; recommendation is largely implicit, inferred from
behavior without an explicit query.

**2. What are the two classical paradigms in recommendation systems?**
Collaborative Filtering (uses only the interaction matrix — "users who agreed before will
agree again") and Content-Based Filtering (uses item attributes — "recommend items similar
to what you already liked"). This project implements both, plus Matrix Factorization and a
Hybrid blend.

**3. What is the cold-start problem?**
The inability to make good recommendations for a new user (no rating history) or a new
item (no ratings yet). Example from this project: 84 users sit exactly at the 20-rating
collection floor; the Hybrid model automatically shifts weight toward the Popularity signal
(0.7/0.3/0.0) for users with fewer than 5 training ratings to mitigate this.
*Follow-up*: "How would you handle a brand-new item with zero ratings?" Content-based
filtering can still recommend it based on attributes (genre, etc.) even with no
interaction history — this is exactly why Content-Based was included alongside CF.

**4. What is the difference between explicit and implicit feedback?**
Explicit: a user directly states preference (a 1–5 star rating, as in MovieLens).
Implicit: preference inferred from behavior (clicks, watch-time, purchases). Implicit
feedback is typically noisier (a click doesn't mean "liked") but far more abundant.

**5. Why did you choose the MovieLens 1M dataset for this project?**
It offers explicit ratings (supports both RMSE-style and ranking-style evaluation), a clean
academic license, and is dense enough (1M+ ratings, ~6K users, ~4K items) to fit a full
similarity-matrix computation in a resource-constrained environment, unlike ml-25m which
would require lossy shortcuts to remain computationally tractable.

---

## B. Python / Engineering

**6. Why use a sparse matrix (scipy.sparse.csr_matrix) instead of a dense NumPy array for the user-item matrix?**
This project's matrix is 95.15% sparse (6,035×3,415, 999,513 non-zero entries out of 20.6M
possible cells). Dense float32 storage would need ~82.5 MB; sparse CSR needs only ~8 MB — a
measured ~10× reduction. At larger catalog sizes, dense storage becomes infeasible entirely.

**7. What's the difference between CSR and CSC sparse formats?**
CSR (Compressed Sparse Row) is efficient for row-wise operations (e.g., "get all of user
X's ratings"); CSC (Compressed Sparse Column) is efficient for column-wise operations
(e.g., "get all ratings for item Y"). This project uses CSR for the user-item matrix since
recommendation queries are typically per-user, and transposes to compute item-item
similarity in `ItemBasedCF.fit()`.

**8. How do you avoid hard-coded values in production ML code?**
Centralize them in a single configuration module. This project uses `src/config.py` as the
single source of truth for every threshold, seed, and hyperparameter — changing
`MIN_RATINGS_PER_ITEM` in one place propagates consistently to preprocessing, notebooks,
and documentation, rather than needing to hunt down every hard-coded occurrence.

**9. Why did you write unit tests for a data science project?**
Because they catch real, non-obvious bugs. This project's own test suite
(`tests/test_data.py`) caught a genuine defect: a single-pass data-cleaning filter that
failed to guarantee both the item-rating-count and user-rating-count thresholds held
simultaneously after cascading removals. The fix (iterating the filter to convergence) and
the full re-run of the downstream pipeline is documented in the project report, Section 8.1.

**10. What is a fixture in pytest, and how did you use them here?**
A fixture provides reusable, deterministic test setup. `tests/test_recommender.py` uses
small, hand-constructed `toy_ratings`/`toy_movies` fixtures so that algorithm behavior
(e.g., "does the model exclude already-seen items from recommendations") can be verified
against known, hand-computable expected output rather than the full 1M-row dataset.

---

## C. Data Preprocessing

**11. Why did you filter out items with fewer than 5 ratings?**
An item with only 1–4 ratings can't support reliable similarity computation — there's
almost no co-rating signal to learn from — and would artificially inflate coverage metrics
without adding real recommendation value. The threshold is defined once in `src/config.py`
(`MIN_RATINGS_PER_ITEM = 5`) and documented in `data/README.md`.

**12. Why did filtering need to be iterative rather than a single pass?**
Because the two filters interact: removing low-activity users can reduce some items'
rating counts below the item threshold, and removing low-signal items can reduce some
users' rating counts below the user threshold. A single pass over both filters doesn't
guarantee the final data satisfies both constraints — this project's own test suite caught
exactly this bug, and the fix iterates the filter to a fixed point (converged after 3
iterations on this dataset, going from 1,000,209 to 999,513 ratings).

**13. What is data leakage, and how did you prevent it in the train/test split?**
Leakage is using information at training time that wouldn't actually be available at
prediction time. This project uses a **temporal per-user split**: each user's ratings are
sorted by timestamp, and the most recent 20% is held out as test data. This was explicitly
verified — every test row's timestamp was confirmed ≥ that user's maximum training
timestamp, with 0 violations out of 197,510 test rows.

**14. Why a temporal per-user split instead of a global time cutoff or random split?**
A random split ignores chronology and can leak a user's "future" rating into their own
training set. A single global time cutoff would leave many users with zero training or
zero test data, given MovieLens 1M's highly uneven user activity spans (mean 165.6
ratings/user, but ranging from 20 to 2,277). Splitting each user's own timeline
individually keeps every user represented in both sets while still respecting chronology.

**15. How did you handle demographic features (age, gender, occupation)?**
Deliberately excluded them from every ranking model's feature set. The EDA showed the
25–34 age group generates ~40% of ratings and male users generate ~75% of rating volume —
including these as model features risks the model implicitly optimizing for the majority
demographic's taste at the expense of underrepresented users. They're used only for
descriptive segmentation (Phase 6), documented explicitly in `data/README.md`.

---

## D. Feature Engineering

**16. What features did you engineer, and why?**
User-level: `avg_user_rating` (rater generosity/criticism, used for mean-centering),
`user_activity_score` (engagement, used to filter noise from neighbor search). Item-level:
`avg_item_rating` (quality signal for the Popularity Baseline), `item_popularity_score`
(exposure signal, distinguishes broad appeal from niche enthusiasm), `item_rating_std`
(polarization signal).

**17. How did you verify no leakage in your engineered features?**
Every feature is computed purely from ratings/movie metadata that would already exist at
prediction time — no target peeking, no use of test-set information. Verified in
`tests/test_data.py::test_full_pipeline_consistency`.

**18. Why compute `item_rating_std` (rating standard deviation) as a feature?**
It's a polarization signal — a low std means an item is consistently rated (broadly
agreed-upon quality); a high std means the item divides opinion. This is relevant to the
diversity-aware re-ranking discussion in the project's Future Scope.

---

## E. Similarity Metrics

**19. What is cosine similarity, and how is it used here?**
Cosine similarity measures the cosine of the angle between two vectors, ranging from -1 to
1 (or 0 to 1 for non-negative vectors like ratings). It's used in this project for
User-Based CF (between user rating vectors), Item-Based CF (between item rating vectors,
transposed matrix), and Content-Based Filtering (between TF-IDF genre vectors).

**20. What is Pearson correlation, and how does it differ from cosine similarity here?**
Pearson correlation is computed as cosine similarity on mean-centered vectors — each user's
ratings are shifted by subtracting their own average rating before computing cosine
similarity. This corrects for individual rating-scale bias: a user who rates everything
4–5 and a user who rates everything 1–2 can still be identified as having similar *taste*
once centered. In this project, Pearson (Precision@10 = 0.0086) outperformed raw cosine
(0.0065) for User-Based CF — a real, measured improvement from mean-centering.

**21. Why did Item-Based CF outperform User-Based CF so substantially in your results (0.0990 vs 0.0065–0.0086)?**
Item-item similarities are far more stable over time than user-user similarities — an
item's relationship to other items (inferred from its population of raters) drifts much
less than any individual user's evolving taste. This also makes item-item similarity
precomputable entirely offline, whereas user-user similarity must be recomputed as the
user base itself changes. This project's own measured fit times reflect this too:
Item-Based CF fit in 0.28s vs. User-Based CF (cosine) at 1.86s on identical data.

**22. What does a similarity score of exactly 0 mean? What about a negative value?**
0 means no linear relationship in the (possibly centered) rating vectors — no shared
signal. A negative value (possible with Pearson, not with cosine on non-negative raw
ratings) means an inverse relationship — one user/item's high ratings correspond to the
other's low ratings.

**23. Give a real example of item-item similarity from your project.**
The top similar item to "Toy Story" (movie_id=1) is "Toy Story 2," with a cosine similarity
of 0.620, computed directly from `ItemBasedCF.similar_items()` — a genuinely sensible,
inspectable result rather than a cherry-picked example.

---

## F. Collaborative Filtering

**24. Explain User-Based Collaborative Filtering end-to-end.**
Find the K most similar users to a target user (via cosine or Pearson similarity on rating
vectors), then predict the target user's rating for an unseen item as a similarity-weighted
average of the neighbors' ratings for that item, and recommend the top-scoring unseen items.

**25. Explain Item-Based Collaborative Filtering end-to-end.**
Compute item-item similarity from the transposed user-item matrix, then for a target user,
score each unseen item as a similarity-weighted sum over the items the user has already
rated, weighted by both the item-item similarity and the user's given rating.

**26. What are the scalability trade-offs between User-Based and Item-Based CF?**
User-Based CF's similarity computation scales with the number of users and must be
recomputed as the user base grows — problematic for a large, fast-growing user base.
Item-Based CF's similarity computation scales with the number of items, which is typically
far more stable (a catalog grows far more slowly than a user base on most platforms), and
can be precomputed once and reused — the same computational pattern behind Amazon's
"customers who bought this also bought."

**27. What is the neighborhood size (K), and how did you choose it?**
K is the number of most-similar neighbors used for prediction. This project fixed
`CF_TOP_N_NEIGHBORS = 30` in `src/config.py` — a standard default balancing enough
signal against noise from overly distant neighbors. A full sensitivity sweep over K was not
performed and is noted as a limitation.

**28. What happens to a User-Based CF recommendation if the target user has no similar users in the dataset?**
The model returns an empty or near-empty recommendation list — verified explicitly in
`tests/test_recommender.py::test_recommend_unknown_user_returns_empty`. In a production
hybrid system, this is exactly the case the automatic Popularity-weight fallback exists to
handle.

---

## G. Content-Based Filtering

**29. How does your Content-Based model represent movies?**
Each movie's pipe-separated genre string is converted into a TF-IDF vector over the 18
unique genre tokens. TF-IDF down-weights genres common across the whole catalog (e.g.
Drama, which covers 1,603 movies) relative to rarer, more distinctive genres (e.g.
Film-Noir, 44 movies), so similarity reflects distinctive taste rather than catalog-wide
genre frequency.

**30. How is a user profile built for content-based recommendation?**
As the rating-weighted average of the TF-IDF vectors for items the user rated 4 or 5 stars.
Unseen items are then ranked by cosine similarity to this profile vector.

**31. Why did your Content-Based model underperform the Popularity Baseline (0.0093 vs. 0.0395 Precision@10)?**
Genre alone is a weak proxy for actual taste — two users who both like "Comedy" can have
very different specific preferences within that genre. This is a genuine, expected
limitation of content-only features with such a small, coarse attribute set (only 18
genres), reported honestly in this project rather than adjusted to look more favorable.

**32. How would you improve the Content-Based model?**
Add richer item metadata — plot summaries, cast, director, keywords — which MovieLens 1M
does not provide but a production catalog typically would. This is noted explicitly as a
limitation, not silently worked around.

---

## H. Matrix Factorization / SVD

**33. Explain the intuition behind SVD-based matrix factorization for recommendations.**
Represent each user and each item as a vector in a shared, low-dimensional latent-factor
space, such that the dot product of a user's and an item's vectors approximates the
observed rating. This lets the model generalize to unobserved (sparse) user-item pairs by
leveraging shared latent structure, rather than relying only on direct co-occurrence.

**34. What hyperparameters did you use for SVD, and why?**
100 latent factors, 20 training epochs, learning rate 0.005, regularization 0.02 (Surprise
library defaults, fixed in `src/config.py`). These were not exhaustively tuned against this
specific dataset — a documented limitation, not a claim of optimality.

**35. How did you validate your SVD implementation was correct, beyond it just "running"?**
Cross-checked the resulting RMSE (0.890) against published MovieLens-1M benchmarks in the
literature (typically 0.87–0.92 for comparable configurations) — an external sanity check
that the implementation is correct, not merely internally self-consistent.

**36. Why did SVD have strong RMSE (0.890) but comparatively weak ranking metrics (Precision@10 = 0.0274)?**
RMSE measures how close a predicted star rating is to the true rating, averaged across all
predictions — it doesn't specifically optimize for getting the exact Top-10 ranking right.
A model can be well-calibrated on average while still doing a mediocre job of picking the
precise best K items to surface. This is the core reason this project evaluates both
metric families rather than RMSE alone.

**37. What is regularization doing in the SVD objective, and why is it needed?**
It penalizes large latent-factor values, discouraging the model from overfitting to noise
in the sparse, limited training data — particularly important for users/items with few
ratings, where an unregularized model could fit spuriously extreme latent vectors.

---

## I. Evaluation Metrics

**38. What is Precision@K, and why did you choose K=10?**
The fraction of the top-K recommended items that are actually relevant (rating ≥ 4 in this
project's `RELEVANCE_THRESHOLD`). K=10 is a standard choice reflecting a realistic number
of visible recommendation slots in a typical UI.

**39. What is Recall@K, and how does it differ from Precision@K?**
The fraction of all relevant items (in the test set) that were successfully captured in the
top-K recommendations. Precision asks "of what I showed, how much was relevant?"; Recall
asks "of what was relevant, how much did I show?" — they can trade off against each other.

**40. What is MAP@K (Mean Average Precision)?**
Average Precision rewards ranking relevant items earlier in the list (not just including
them anywhere in the top-K); MAP@K is this averaged across all users. It's more sensitive
to ranking order than Precision@K alone.

**41. What is NDCG@K, and why is it useful?**
Normalized Discounted Cumulative Gain — rewards relevant items appearing earlier in the
ranked list (via a logarithmic discount) and normalizes against the best-possible ranking
(IDCG) so scores are comparable across users with different numbers of relevant items. It's
the most ranking-order-sensitive metric used in this project, and Item-Based CF's NDCG@10
(0.1224) was the highest across all seven model variants tested.

**42. Why did you include Coverage, Diversity, and Novelty metrics alongside the ranking metrics?**
Because a model can score well on ranking metrics while only ever recommending the same
small set of already-popular items — exactly what this project's EDA found (top 20% of
items drive 62.6% of ratings). This project's own measured Coverage confirms it: the
Popularity Baseline reaches only 0.97% of the catalog across a 500-user sample, versus
7.85% for Item-Based CF and 21.47% for SVD.

**43. How do you compute Novelty, and what does a higher value mean?**
Mean self-information of recommended items: `-log2(popularity_probability)`. A higher
value means the model recommends less-obvious, less-popular items on average. SVD had the
highest measured Novelty (11.32) of the three models compared at the system level.

**44. What is Coverage, and what did you find for the Popularity Baseline specifically?**
The fraction of the total catalog that appears in any user's recommendation list, across
the evaluation sample. The Popularity Baseline reached only 0.97% catalog coverage — a
direct, measured confirmation of the "everyone sees the same head items" failure mode that
motivated including this metric in the first place.

**45. Why did you evaluate all seven model variants on an identical, fixed sample of users?**
For a fair, apples-to-apples comparison. An earlier version of this project's evaluation
used different sample sizes per model (5,955 vs. 1,480 vs. 788 users) — caught during
development and corrected by re-running every model against the same seed-fixed 1,500-user
sample (`reports/eval_sample_user_ids.json`) before drawing any conclusions.

---

## J. Cold Start, Scalability, and System Design

**46. What would you do if a new user has no rating history?**
Fall back to the Popularity Baseline (works with zero personalization data) or, if any
demographic/context signal is available, a context-aware cold-start heuristic. This
project's Hybrid model implements exactly this: automatic weight-shift toward Popularity
for users below a 5-rating threshold.

**47. What if an item has no interactions yet?**
Content-Based Filtering can still recommend it based on attributes (genre, etc.) even with
zero ratings, since it doesn't depend on the interaction matrix at all — this is precisely
why Content-Based Filtering remains valuable in a hybrid system even though it
underperformed as a standalone ranker in this project's evaluation.

**48. How would you scale Item-Based CF to a catalog of millions of items?**
The current implementation uses a dense similarity matrix, which becomes infeasible beyond
roughly 50,000–100,000 items. At larger scale, this would move to an approximate
nearest-neighbor index (e.g., FAISS or Annoy) to keep both memory and lookup time
tractable — documented explicitly in this project's report (Section 21.5.4) as a real,
scoped next step rather than assumed away.

**49. How would you evaluate recommendations without explicit ratings (implicit feedback only)?**
Redefine "relevant" as an observed implicit action (click, purchase, watch-to-completion)
rather than a star-rating threshold, and use the same ranking metrics (Precision@K,
Recall@K, NDCG@K) against held-out implicit interactions. RMSE/MAE become inapplicable
since there's no explicit rating to predict.

**50. How would you detect recommendation bias in a system like this one?**
Break down ranking metrics (e.g., Precision@K) by demographic segment and compare — a
formal fairness audit this project explicitly did not perform, noted as a limitation. Also
monitor Coverage/Novelty over time to detect drift toward an increasingly narrow,
popularity-dominated recommendation set.

**51. How would you improve diversity in this project's selected model (Item-Based CF)?**
Apply a diversity-aware re-ranking layer (e.g., Maximal Marginal Relevance) on top of
Item-Based CF's ranked list, trading a small amount of precision for materially better
catalog coverage — combining Item-CF's accuracy strength with the discovery strength
observed in SVD (21.47% vs. 7.85% coverage). Documented as a concrete Future Scope item.

**52. How would you deploy this model to production, beyond the Streamlit demo?**
Separate offline training (scheduled or event-triggered retraining pipeline) from online
serving (a low-latency API loading precomputed similarity matrices/model artifacts, similar
to how `app.py` uses `st.cache_resource` to load models once per process). Add a CI
evaluation gate using the existing `evaluate_model()` function to block deploying a model
that regresses below the current 0.099 Precision@10 baseline.

**53. How would you design an A/B test to validate this project's offline findings?**
Split live traffic between the current production strategy (e.g., popularity-only) and the
new Item-Based CF model, holding all else constant, and measure the actual business KPIs
this project explicitly could not measure offline — CTR, conversion rate, session length —
with a predetermined minimum sample size and duration to reach statistical significance
before deciding.

---

## K. Business and Scenario Questions

**54. What business value does personalization actually provide, based on your results?**
This project can only defend the *technical* claim: Item-Based CF is ~2.5× more precise
than a "most popular" baseline on held-out data. Whether that precision improvement
translates to increased engagement, conversion, or revenue is a business hypothesis
consistent with published industry patterns — not something this offline academic dataset
can prove without live A/B data. This distinction is maintained explicitly throughout the
project (see `reports/business_insights.md`).

**55. If your manager asked you to justify choosing Item-Based CF over SVD for a real product, what would you say?**
It depends on the product's priority. If ranking precision on a small number of visible
recommendation slots matters most (e.g., a "Recommended for You" homepage rail),
Item-Based CF's 0.0990 Precision@10 is the stronger choice. If catalog discovery and
avoiding a narrow, over-concentrated recommendation set matters more (e.g., a "surprise me"
or discovery-focused feature), SVD's 21.47% coverage and higher Diversity/Novelty would be
the better fit. I'd present both, with the actual trade-off data, rather than picking one
without surfacing the choice.

**56. Your Hybrid model didn't outperform your best single model. Doesn't that mean the project failed?**
No — it's an honest empirical finding, not a failure of the project's rigor. A project that
tuned the hybrid weights after the fact until it looked better would be less trustworthy,
not more. The correct response to a negative result is to report it accurately and note the
concrete next step (a proper hybrid-weight search, or including Item-Based CF itself as a
hybrid component) rather than to suppress or spin it.
