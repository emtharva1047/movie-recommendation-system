# Dataset setup

MovieLens 1M is not distributed in this repository. See the root README and the official [GroupLens usage terms](https://files.grouplens.org/datasets/movielens/ml-1m-README.txt). Obtain it directly from GroupLens if you accept those terms, then generate processed data and model files locally by following `src/` and `notebooks/`.
