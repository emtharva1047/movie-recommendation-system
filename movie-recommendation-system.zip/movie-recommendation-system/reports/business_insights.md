# Business Insights

This document translates the technical results from Phases 5–17 into business
language. Per the project's core rule, every statement below is labeled as
either an **Observed Data Insight** (directly computed from this dataset/these
models) or a **Business Hypothesis** (an inference consistent with published
industry patterns, not something this offline academic dataset can prove).
No revenue, conversion, or retention numbers are stated as fact anywhere in
this project, because no live traffic or transaction data exists here.

## 1. Personalization Value
**Observed Data Insight**: Item-Based Collaborative Filtering achieves Precision@10 = 0.099 and NDCG@10 = 0.122, roughly **2.5x** the Popularity Baseline's Precision@10 (0.0395) on identical held-out data.
**Business Hypothesis**: A production system swapping a "most popular" rail for a personalized item-based CF rail would likely surface more individually relevant content, which published industry case studies (Netflix, Amazon) associate with higher engagement — this project cannot measure that causally without live A/B data.

## 2. Catalog Discovery / Long-Tail Utilization
**Observed Data Insight**: The Popularity Baseline recommends from only 0.97% of the catalog across a 500-user sample; Item-Based CF reaches 7.85%; SVD reaches 21.32% (`reports/system_metrics.json`).
**Business Hypothesis**: A pure popularity-driven homepage under-exposes ~99% of the catalog to any given user cohort — consistent with the EDA finding that the top 20% of items already account for 62.6% of all historical ratings (`reports/eda_insights.md`). Diversifying recommendation strategy (e.g., blending in SVD-driven discovery slots) is a reasonable lever for increasing catalog utilization, though the resulting engagement/revenue effect would need to be measured in a live experiment, not assumed.

## 3. Cross-Selling and Upselling
**Observed Data Insight**: Item-Based CF's `similar_items()` output (Phase 12) produces genre- and taste-consistent neighbors — e.g., Toy Story's top similar item is Toy Story 2 (cosine similarity 0.620), which is exactly the kind of complementary-item signal used for "customers who liked this also liked" placements.
**Business Hypothesis**: Surfacing these similar-item lists at a decision point (e.g., after a user finishes an item) is a standard, low-risk cross-sell mechanism in industry — again, this project can only demonstrate the *signal exists and is coherent*, not that it converts.

## 4. Personalization for New vs. Established Users (Cold Start)
**Observed Data Insight**: 84 users in this dataset sit exactly at the cold-start floor (20 ratings, the minimum by MovieLens collection design); collaborative filtering models require rating history to function, and cannot personalize for a zero-history user by construction.
**Business Hypothesis**: The Hybrid model's automatic weight-shift toward the Popularity signal for low-activity users (`cold_start_threshold=5` in `src/recommender.py`) is a standard mitigation — but this project's offline hybrid evaluation (Precision@10 = 0.0239) did not outperform pure Item-Based CF, so I am **not** claiming the hybrid approach is superior; the honest empirical finding here is that the simpler, single-algorithm model performed best on this dataset with these hyperparameters.

## 5. User Segments Worth Product Attention
**Observed Data Insight** (Phase 6): Low-activity users (Q1 quartile, ~1,519 users) rate more generously on average (3.77) than high-activity power users (Q4, 3.54); 395 users are "super-active" (>500 ratings), led by user 4169 with 2,277 ratings.
**Business Hypothesis**: Power users are simultaneously the most valuable training-data source (dense signal) and the most quality-critical audience (lower average satisfaction) — a product team might treat this segment as an early-access group for testing new recommendation strategies before wider rollout, since their feedback is likely to be a stricter quality bar.

## 6. Demographic Fairness Consideration
**Observed Data Insight** (Phase 5/6): 25-34 year-olds generate ~40% of all ratings; men generate ~75% of rating volume in this specific dataset.
**Technical/Business Decision**: This project deliberately excludes gender/age/occupation from the ranking-model feature set (documented in `data/README.md`) specifically to avoid the models implicitly optimizing for the majority demographic's taste profile at the expense of underrepresented users — a standard fairness consideration in production recommender systems.

## 7. Genre-Level Findings
**Observed Data Insight** (Phase 5): Horror has the lowest average rating (3.22) despite being a reasonably large genre (343 movies); Film-Noir has the highest average rating (4.08) but is the smallest genre (44 movies).
**Business Hypothesis**: This is consistent with self-selection — niche-genre viewers already know their taste and rate what they chose to watch highly, while a broad-appeal genre like Horror draws a wider, more mixed-satisfaction audience. A content-based recommender naive to this effect (Phase 10, which underperformed the baseline at Precision@10 = 0.0093) risks over-recommending Horror on thin genre-overlap signal alone — a concrete, data-grounded reason why this project favors collaborative signal over content signal as the primary ranking driver.

---

## Explicit Boundary Statement
This project reports **technical KPIs only** (Precision@K, Recall@K, MAP@K, NDCG@K, RMSE, MAE, Coverage, Diversity, Novelty), all computed from real held-out data. It does **not** report CTR, conversion rate, AOV uplift, or retention change, because no live traffic or purchase data exists in this academic dataset. Any statement above framed as a "Business Hypothesis" should be read as an industry-standard expectation, not a proven outcome of this specific project.
