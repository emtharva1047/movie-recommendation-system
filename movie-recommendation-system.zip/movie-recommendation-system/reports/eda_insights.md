# Exploratory Data Analysis — Insights

All figures referenced below are in `figures/` and were generated directly from
`data/processed/ratings_clean.csv`, `movies_clean.csv`, `users_clean.csv` (999,517 ratings,
6,035 users, 3,416 items). All numbers are computed, not estimated.

## 1. Rating Distribution (`01_rating_distribution.png`)
Counts: 1★=56,059 · 2★=107,441 · 3★=261,005 · 4★=348,786 · 5★=226,226. Mean 3.58, median 4.

**Business insight**: Users rate skew positive — most ratings are 3★ and above (83.9% of all ratings). This is a well-known selection-bias pattern: people are more likely to rate movies they chose to watch and generally liked.
**Technical insight**: Because most ratings cluster at 3-5, a naive model predicting "4" for every user-item pair would already achieve a deceptively low RMSE — this is why the report evaluates ranking metrics (Precision@K, NDCG) alongside RMSE, not RMSE alone.
**Business recommendation**: Don't treat "average rating" alone as a strong relevance signal — combine it with rating count and ranking-based recommendation scores.

## 2. User Activity Distribution (`02_user_activity_distribution.png`)
Mean 165.6 ratings/user, median 96, min 20 (by design), max 2,277. Highly right-skewed (std 192.6, larger than the mean).

**Business insight**: A small set of "power users" contributes disproportionately to the ratings volume. The most active user (ID 4169) alone rated 2,277 movies.
**Technical insight**: This skew means collaborative filtering neighborhoods will be dominated by a handful of very active users unless similarity weighting accounts for it — informs the neighbor-count hyperparameter (`CF_TOP_N_NEIGHBORS=30`) chosen in Phase 11/12.
**Business recommendation**: Power users are a valuable source of training signal but should not dominate popularity-based recommendations shown to typical users — worth monitoring for popularity bias.

## 3. Long-Tail Item Popularity (`03_long_tail_distribution.png`)
The top 20% of items (by rating count) account for **62.61%** of all ratings.

**Business insight**: Classic long-tail / Pareto pattern — a small fraction of the catalog drives most engagement, while ~80% of movies are comparatively under-exposed.
**Technical insight**: A pure popularity-based baseline will always recommend the same head items, which is why Novelty and Coverage metrics are essential later (Phase 16) to catch a model that "cheats" by only recommending the head.
**Business recommendation**: A production system should deliberately balance relevance with catalog coverage to surface long-tail titles — improves discovery and utilizes underexposed inventory.

## 4. Most Popular Items (`04_most_popular_items.png`)
Top-rated-by-volume: American Beauty (1999) — 3,426 ratings, avg 4.32; Star Wars Episode IV — 2,991 ratings, avg 4.45; Star Wars Episode V — 2,990 ratings, avg 4.29.

**Business insight**: Popularity and quality (avg rating) are correlated but not identical here — Star Wars IV has a higher average rating (4.45) than American Beauty (4.32) despite fewer total ratings, showing volume and quality are separate signals.
**Technical insight**: This item list forms the actual output of the Phase 9 Popularity Baseline model — used later to sanity-check that baseline recommendations look reasonable.
**Business recommendation**: A "most popular" homepage rail and a "highest rated" rail are genuinely different, useful surfaces — worth exposing both in a real product.

## 5. Most Active Users (`05_most_active_users.png`)
Top user (ID 4169) rated 2,277 movies — over 10x the median user's activity.

**Business insight**: A small group of highly engaged users could be a target segment for beta-testing new recommendation strategies before wider rollout.
**Technical insight**: These users provide dense training signal, useful for validating user-based CF neighbor quality.

## 6. Item Popularity Distribution (`06_item_popularity_distribution.png`)
Mean 292.6 ratings/item, median 146, min 4 (post-filtering floor), max 3,426 (American Beauty).

**Business insight**: Confirms the same long-tail pattern from a per-item lens — most items sit well below the mean.
**Technical insight**: Median (146) far below mean (292.6) confirms right-skew — informs the choice of `MIN_RATINGS_PER_ITEM=5` filtering threshold as conservative (keeps the vast majority of the tail rather than aggressively pruning it).

## 7. User-Item Interaction Heatmap (`07_user_item_heatmap.png`)
Sampled top-40 users × top-40 items: 1,515 of 1,600 cells populated (94.7% dense in this dense subsample — contrasts sharply with the 95.53% *sparse* full matrix).

**Business insight**: Illustrates concretely why "everyone rates everything" is false for the full catalog — even the most engaged users only overlap heavily with other engaged users on popular items.
**Technical insight**: This dense subsample is exactly the kind of neighborhood collaborative filtering exploits — most of the matrix outside this dense core is empty, which is the computational and quality challenge CF and SVD both have to solve.

## 8. Interaction Density (`12_interaction_density.png`)
Top-100 users × top-100 items subsample: 87.74% dense, vs. 4.47% dense (95.53% sparse) for the full matrix.

**Technical insight**: Confirms the matrix is not uniformly sparse — density is highly concentrated among active users and popular items. This directly motivates using **Matrix Factorization (SVD)** in Phase 13, which handles global sparsity far better than direct similarity computation on raw sparse vectors.

## 9. Genre Distribution (`08_genre_distribution.png`)
Drama (1,603 movies) and Comedy (1,200) dominate the catalog; Film-Noir (44) and Western (68) are rarest.

**Business insight**: Catalog composition is Drama/Comedy-heavy — any content-based recommender will naturally be strong in these genres and weaker for niche genres due to data volume.
**Technical insight**: Directly informs the TF-IDF vocabulary size in Phase 10 (18 genres total — a compact, tractable feature space for content-based cosine similarity).

## 10. Average Rating by Genre (`09_avg_rating_by_genre.png`)
Highest avg rating: Film-Noir (4.08), Documentary (3.94), War (3.89). Lowest: Horror (3.22), Children's (3.42), Fantasy (3.45).

**Business insight**: Niche genres (Film-Noir, Documentary) have small but highly satisfied audiences — a self-selection effect (people who choose niche films tend to already know they'll like them). Horror has the broadest, least consistent audience satisfaction.
**Technical insight**: A genre-naive content-based recommender risks over-recommending Horror to users who rated one horror movie highly, since the category itself averages lower — the content-based Phase 10 model should be read with this caveat.

## 11. Ratings by Age Group (`10_ratings_by_age_group.png`)
25-34 age group is the most active (395,381 ratings, ~40% of all ratings), followed by 35-44 (198,885) and 18-24 (183,383).

**Business insight**: The 25-34 demographic is the core engaged audience for this platform — consistent with early-2000s internet/movie-rating platform adoption patterns.
**Technical insight**: Demographic imbalance is a reason this project explicitly excludes age/gender/occupation from ranking-model features (see `data/README.md`) — using them directly risks the model implicitly over-fitting to the dominant demographic's taste profile.

## 12. Gender Analysis (`11_gender_analysis.png`)
753,238 ratings from male users (avg 3.57) vs. 246,279 from female users (avg 3.62) — women rate marginally higher on average, men rate ~3x more volume.

**Business insight**: Male users dominate ratings volume in this dataset (a known characteristic of the original MovieLens 1M user base, not a general claim about movie audiences).
**Technical insight**: Reinforces the earlier design decision to keep demographic features descriptive-only rather than model inputs, to avoid the ranking model skewing toward the majority demographic's preferences.

---

## Summary of Key EDA-Derived Design Decisions
1. **Sparsity (95.53%) → justifies Matrix Factorization (SVD)** as a core algorithm, since raw similarity methods degrade under this level of sparsity.
2. **Long tail (top 20% items = 62.6% of ratings) → justifies Coverage/Novelty/Diversity metrics**, not just Precision/Recall, in Phase 16.
3. **Demographic imbalance → justifies excluding gender/age/occupation from ranking-model features.**
4. **Genre imbalance (Drama/Comedy dominant) → sets realistic expectations for content-based model performance across genres.**
