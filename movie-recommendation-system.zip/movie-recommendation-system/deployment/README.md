# Deployment notes

The app requires locally generated processed MovieLens data and model artifacts. These are not included in this repository because the MovieLens dataset is subject to GroupLens terms. Review the root README, obtain the dataset directly from GroupLens under its terms, then run the project workflow before launching `streamlit run app.py`.
