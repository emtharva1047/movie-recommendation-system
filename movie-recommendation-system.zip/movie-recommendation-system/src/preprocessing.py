"""
preprocessing.py
-----------------
Data cleaning pipeline for the MovieLens 1M dataset.

Design principle: every filtering decision here is driven by a threshold
defined in src/config.py and justified in data/README.md /
docs/technical_documentation.md, not applied arbitrarily.
"""

import re
from typing import Tuple

import pandas as pd

from src.config import MIN_RATINGS_PER_ITEM, MIN_RATINGS_PER_USER
from src.logging_config import get_logger

logger = get_logger(__name__)


def check_missing_and_duplicates(df: pd.DataFrame, name: str) -> None:
    """Log missing-value and duplicate-row counts for a DataFrame (audit step)."""
    n_missing = df.isnull().sum().sum()
    n_duplicates = df.duplicated().sum()
    logger.info("[%s] missing values: %d, duplicate rows: %d", name, n_missing, n_duplicates)


def clean_ratings(ratings: pd.DataFrame) -> pd.DataFrame:
    """
    Clean the ratings DataFrame.

    Steps (each justified):
    1. Drop exact duplicate rows (defensive; verified 0 present in raw data,
       kept here so the pipeline is robust if source data changes).
    2. Validate rating values fall in {1,2,3,4,5} (defensive; MovieLens
       ratings are whole-star 1-5 by design, but this guards against any
       future corrupted input).
    3. ITERATIVELY filter out items with fewer than MIN_RATINGS_PER_ITEM
       ratings and users with fewer than MIN_RATINGS_PER_USER ratings,
       repeating until both constraints hold simultaneously.

       WHY ITERATIVE (not a single pass): filtering low-activity users
       first can drop enough of an item's ratings to push it below the
       item threshold, and vice versa — a single pass over both filters
       does not guarantee the final data actually satisfies both
       thresholds. This was caught by tests/test_data.py::
       test_clean_ratings_removes_low_signal_items, which failed under a
       single-pass implementation because a handful of items fell below
       5 ratings only after user filtering removed some of their raters.
       Iterating to a fixed point is the standard, correct way to enforce
       both constraints together in collaborative-filtering preprocessing.

    Returns
    -------
    pd.DataFrame
        Cleaned ratings, with a reset integer index, guaranteed to satisfy
        both MIN_RATINGS_PER_ITEM and MIN_RATINGS_PER_USER simultaneously.
    """
    before = len(ratings)
    df = ratings.drop_duplicates().copy()
    df = df[df["rating"].isin([1, 2, 3, 4, 5])]

    iteration = 0
    while True:
        iteration += 1
        item_counts = df.groupby("movie_id").size()
        valid_items = item_counts[item_counts >= MIN_RATINGS_PER_ITEM].index
        df_next = df[df["movie_id"].isin(valid_items)]

        user_counts = df_next.groupby("user_id").size()
        valid_users = user_counts[user_counts >= MIN_RATINGS_PER_USER].index
        df_next = df_next[df_next["user_id"].isin(valid_users)]

        if len(df_next) == len(df):
            df = df_next
            break
        df = df_next

    logger.info("clean_ratings: converged after %d filtering iteration(s)", iteration)

    df = df.reset_index(drop=True)
    after = len(df)
    logger.info(
        "clean_ratings: %d -> %d rows (%d removed, %.2f%% retained)",
        before, after, before - after, 100 * after / before,
    )
    return df


def clean_movies(movies: pd.DataFrame) -> pd.DataFrame:
    """
    Clean the movies DataFrame and engineer a `year` column parsed from
    the title (e.g. "Toy Story (1995)" -> year=1995).
    """
    df = movies.drop_duplicates().copy()
    year_extracted = df["title"].str.extract(r"\((\d{4})\)\s*$")
    df["year"] = pd.to_numeric(year_extracted[0], errors="coerce")
    n_missing_year = df["year"].isnull().sum()
    if n_missing_year > 0:
        logger.warning("%d movies have no parseable release year", n_missing_year)
    df["genres_list"] = df["genres"].apply(lambda g: g.split("|"))
    return df.reset_index(drop=True)


def clean_users(users: pd.DataFrame) -> pd.DataFrame:
    """Clean the users DataFrame and map coded age/occupation to readable labels."""
    df = users.drop_duplicates().copy()

    age_map = {
        1: "Under 18", 18: "18-24", 25: "25-34", 35: "35-44",
        45: "45-49", 50: "50-55", 56: "56+",
    }
    occupation_map = {
        0: "other/not specified", 1: "academic/educator", 2: "artist",
        3: "clerical/admin", 4: "college/grad student", 5: "customer service",
        6: "doctor/health care", 7: "executive/managerial", 8: "farmer",
        9: "homemaker", 10: "K-12 student", 11: "lawyer", 12: "programmer",
        13: "retired", 14: "sales/marketing", 15: "scientist",
        16: "self-employed", 17: "technician/engineer", 18: "tradesman/craftsman",
        19: "unemployed", 20: "writer",
    }
    df["age_label"] = df["age"].map(age_map)
    df["occupation_label"] = df["occupation"].map(occupation_map)
    return df.reset_index(drop=True)


def run_cleaning_pipeline(
    ratings: pd.DataFrame, movies: pd.DataFrame, users: pd.DataFrame
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Run the full cleaning pipeline and return (ratings, movies, users)."""
    for df, name in [(ratings, "ratings"), (movies, "movies"), (users, "users")]:
        check_missing_and_duplicates(df, name)

    ratings_clean = clean_ratings(ratings)
    movies_clean = clean_movies(movies)
    users_clean = clean_users(users)

    # Keep only movies/users that still appear in the cleaned ratings
    ratings_clean = ratings_clean[
        ratings_clean["movie_id"].isin(movies_clean["movie_id"])
        & ratings_clean["user_id"].isin(users_clean["user_id"])
    ].reset_index(drop=True)

    logger.info(
        "Final cleaned dataset: %d ratings, %d users, %d items",
        len(ratings_clean),
        ratings_clean["user_id"].nunique(),
        ratings_clean["movie_id"].nunique(),
    )
    return ratings_clean, movies_clean, users_clean


if __name__ == "__main__":
    from src.data_loader import load_all
    from src.config import RATINGS_CLEAN_FILE, MOVIES_CLEAN_FILE, USERS_CLEAN_FILE

    ratings, movies, users = load_all()
    ratings_clean, movies_clean, users_clean = run_cleaning_pipeline(ratings, movies, users)

    ratings_clean.to_csv(RATINGS_CLEAN_FILE, index=False)
    movies_clean.to_csv(MOVIES_CLEAN_FILE, index=False)
    users_clean.to_csv(USERS_CLEAN_FILE, index=False)
    print("Cleaned files saved to data/processed/")
