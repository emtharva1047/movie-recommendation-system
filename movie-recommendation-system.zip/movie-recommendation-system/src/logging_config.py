"""
logging_config.py
------------------
Centralized logging setup. Every module calls get_logger(__name__) instead
of configuring its own handlers, so log formatting and log-file location
stay consistent across the whole project.
"""

import logging
import sys
from pathlib import Path

from src.config import LOGS_DIR

LOG_FILE = LOGS_DIR / "recommendation_system.log"
LOG_FORMAT = "%(asctime)s | %(name)s | %(levelname)s | %(message)s"


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """
    Create (or retrieve) a configured logger.

    Parameters
    ----------
    name : str
        Name of the logger, typically __name__ of the calling module.
    level : int
        Logging level (default: logging.INFO).

    Returns
    -------
    logging.Logger
        Configured logger writing to both stdout and a shared log file.
    """
    logger = logging.getLogger(name)

    if logger.handlers:
        # Logger already configured (avoid duplicate handlers on re-import)
        return logger

    logger.setLevel(level)

    formatter = logging.Formatter(LOG_FORMAT)

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    file_handler = logging.FileHandler(LOG_FILE)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    logger.propagate = False
    return logger
