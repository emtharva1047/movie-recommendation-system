"""
train_test_split.py
--------------------
Implements a TEMPORAL PER-USER train/test split.

WHY this strategy (not random row split):
A naive random split can put a user's *earlier* rating in the test set
and a *later* rating (which may reflect drift in taste, or knowledge of
the earlier rating) in the training set -- this is temporal leakage and
inflates offline metrics unrealistically relative to real deployment,
where a model only ever has access to a user's PAST behavior when
predicting their future behavior.

Per-user (rather than a single global time cutoff) is used because a
single global cutoff would leave many users with zero training data
(anyone who joined after the cutoff) or zero test data (anyone who
stopped rating before the cutoff) -- MovieLens 1M spans under 3 years,
and user activity is highly uneven (see EDA), so a global cutoff would
distort the evaluation population. Splitting each user's own timeline
individually keeps every user present in both sets while still
respecting chronology.
"""

from typing import Tuple

import numpy as np
import pandas as pd

from src.config import RANDOM_SEED, TEST_SIZE
from src.logging_config import get_logger

logger = get_logger(__name__)


def temporal_per_user_split(
    ratings: pd.DataFrame, test_size: float = TEST_SIZE, min_train_ratings: int = 5
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    For each user, sort their ratings by timestamp and hold out the most
    recent `test_size` fraction as the test set; the rest is training data.

    Users with too few ratings to guarantee at least `min_train_ratings`
    training rows after the split are kept entirely in training (their
    test contribution would be statistically meaningless and would only
    add noise to ranking metrics).
    """
    train_parts = []
    test_parts = []

    for user_id, group in ratings.groupby("user_id"):
        group = group.sort_values("timestamp")
        n = len(group)
        n_test = int(np.floor(n * test_size))

        if n - n_test < min_train_ratings:
            train_parts.append(group)
            continue

        train_parts.append(group.iloc[: n - n_test])
        test_parts.append(group.iloc[n - n_test :])

    train_df = pd.concat(train_parts).reset_index(drop=True)
    test_df = (
        pd.concat(test_parts).reset_index(drop=True)
        if test_parts
        else pd.DataFrame(columns=ratings.columns)
    )

    logger.info(
        "Temporal per-user split: %d train rows, %d test rows (%d users have test rows)",
        len(train_df), len(test_df), test_df["user_id"].nunique() if len(test_df) else 0,
    )
    return train_df, test_df


if __name__ == "__main__":
    from src.config import RATINGS_CLEAN_FILE, TRAIN_RATINGS_FILE, TEST_RATINGS_FILE

    ratings = pd.read_csv(RATINGS_CLEAN_FILE)
    train_df, test_df = temporal_per_user_split(ratings)

    # Sanity check: no leakage -- every test row's timestamp must be >= the
    # max training timestamp for that same user.
    merged_check = test_df.merge(
        train_df.groupby("user_id")["timestamp"].max().rename("max_train_ts"),
        on="user_id", how="left",
    )
    violations = (merged_check["timestamp"] < merged_check["max_train_ts"]).sum()
    if violations > 0:
        raise ValueError(f"Temporal leakage detected: {violations} test rows precede training data")
    print(f"Leakage check passed: 0 violations out of {len(test_df)} test rows")

    train_df.to_csv(TRAIN_RATINGS_FILE, index=False)
    test_df.to_csv(TEST_RATINGS_FILE, index=False)
    print("train:", train_df.shape, "test:", test_df.shape)
