"""
evaluation.py
--------------
Implements ranking metrics (Precision@K, Recall@K, MAP@K, NDCG@K),
prediction metrics (RMSE, MAE), and system-level metrics (Coverage,
Diversity, Novelty).

WHY multiple metric families:
- Prediction metrics (RMSE/MAE) measure how close a predicted rating is
  to the true rating -- relevant for SVD, irrelevant for pure ranking
  models like popularity/content-based that don't predict star ratings.
- Ranking metrics (Precision@K/Recall@K/MAP@K/NDCG@K) measure whether the
  TOP-K items actually shown to a user are the ones they'd engage with --
  this is what actually matters in a real UI, where only a handful of
  slots are visible.
- System-level metrics (Coverage/Diversity/Novelty) catch a model that
  scores well on ranking metrics by only ever recommending the same
  small set of blockbuster items (see Phase 5 long-tail finding) --
  a model that never surfaces 95% of the catalog is a business risk even
  if its Precision@K looks good.
"""

from typing import Dict, List, Set

import numpy as np
import pandas as pd

from src.logging_config import get_logger

logger = get_logger(__name__)


def precision_at_k(recommended: List[int], relevant: Set[int], k: int) -> float:
    if k == 0:
        return 0.0
    top_k = recommended[:k]
    if not top_k:
        return 0.0
    hits = sum(1 for item in top_k if item in relevant)
    return hits / len(top_k)


def recall_at_k(recommended: List[int], relevant: Set[int], k: int) -> float:
    if not relevant:
        return 0.0
    top_k = recommended[:k]
    hits = sum(1 for item in top_k if item in relevant)
    return hits / len(relevant)


def average_precision_at_k(recommended: List[int], relevant: Set[int], k: int) -> float:
    if not relevant:
        return 0.0
    top_k = recommended[:k]
    hits = 0
    sum_precisions = 0.0
    for i, item in enumerate(top_k, start=1):
        if item in relevant:
            hits += 1
            sum_precisions += hits / i
    if hits == 0:
        return 0.0
    return sum_precisions / min(len(relevant), k)


def ndcg_at_k(recommended: List[int], relevant: Set[int], k: int) -> float:
    top_k = recommended[:k]
    dcg = 0.0
    for i, item in enumerate(top_k, start=1):
        rel = 1.0 if item in relevant else 0.0
        dcg += rel / np.log2(i + 1)
    ideal_hits = min(len(relevant), k)
    idcg = sum(1.0 / np.log2(i + 1) for i in range(1, ideal_hits + 1))
    if idcg == 0:
        return 0.0
    return dcg / idcg


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2)))


def mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(np.abs(np.asarray(y_true) - np.asarray(y_pred))))


def catalog_coverage(all_recommended_items: Set[int], total_catalog_size: int) -> float:
    """Fraction of the full catalog that ever appears in ANY user's Top-K list."""
    if total_catalog_size == 0:
        return 0.0
    return len(all_recommended_items) / total_catalog_size


def novelty(recommended_lists: List[List[int]], item_popularity: pd.Series) -> float:
    """
    Mean self-information of recommended items: -log2(popularity_probability).
    Higher novelty = recommends less-obvious (less popular) items on average.
    """
    total_interactions = item_popularity.sum()
    scores = []
    for rec_list in recommended_lists:
        for item in rec_list:
            p = item_popularity.get(item, 1) / total_interactions
            scores.append(-np.log2(p))
    return float(np.mean(scores)) if scores else 0.0


def diversity(recommended_lists: List[List[int]], item_similarity_lookup) -> float:
    """
    Mean intra-list dissimilarity (1 - avg pairwise cosine similarity)
    across all users' recommended lists. Higher = more diverse lists.

    item_similarity_lookup: callable(item_a, item_b) -> similarity in [0,1]
    """
    all_scores = []
    for rec_list in recommended_lists:
        if len(rec_list) < 2:
            continue
        sims = []
        for i in range(len(rec_list)):
            for j in range(i + 1, len(rec_list)):
                sims.append(item_similarity_lookup(rec_list[i], rec_list[j]))
        if sims:
            all_scores.append(1 - np.mean(sims))
    return float(np.mean(all_scores)) if all_scores else 0.0


def evaluate_model(
    recommend_fn,
    test_df: pd.DataFrame,
    relevance_threshold: int,
    k: int,
    user_sample: List[int] = None,
) -> Dict[str, float]:
    """
    Evaluate a recommender's ranking quality against held-out test ratings.

    recommend_fn(user_id) -> List[int]  (ordered list of recommended item ids)
    """
    test_by_user = test_df[test_df["rating"] >= relevance_threshold].groupby("user_id")["movie_id"].apply(set)
    users = user_sample if user_sample is not None else list(test_by_user.index)

    precisions, recalls, aps, ndcgs = [], [], [], []
    evaluated_users = 0

    for user_id in users:
        relevant = test_by_user.get(user_id, set())
        if not relevant:
            continue
        recommended = recommend_fn(user_id)
        if recommended is None:
            continue
        precisions.append(precision_at_k(recommended, relevant, k))
        recalls.append(recall_at_k(recommended, relevant, k))
        aps.append(average_precision_at_k(recommended, relevant, k))
        ndcgs.append(ndcg_at_k(recommended, relevant, k))
        evaluated_users += 1

    return {
        "precision_at_k": float(np.mean(precisions)) if precisions else 0.0,
        "recall_at_k": float(np.mean(recalls)) if recalls else 0.0,
        "map_at_k": float(np.mean(aps)) if aps else 0.0,
        "ndcg_at_k": float(np.mean(ndcgs)) if ndcgs else 0.0,
        "n_users_evaluated": evaluated_users,
    }
