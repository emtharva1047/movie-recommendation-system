"""
data_loader.py
---------------
Loads the raw MovieLens 1M .dat files into validated pandas DataFrames.

Why this module exists: the raw files use a non-standard '::' delimiter
and carry no header row. Centralizing the parsing logic here means every
notebook and script gets identically-typed, identically-named columns,
which prevents the classic bug of one script calling a column 'userId'
and another calling it 'user_id'.
"""

from pathlib import Path
from typing import Tuple

import pandas as pd

from src.config import MOVIES_FILE, RATINGS_FILE, USERS_FILE
from src.logging_config import get_logger

logger = get_logger(__name__)

RATINGS_COLUMNS = ["user_id", "movie_id", "rating", "timestamp"]
MOVIES_COLUMNS = ["movie_id", "title", "genres"]
USERS_COLUMNS = ["user_id", "gender", "age", "occupation", "zip_code"]


def _validate_file_exists(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(
            f"Expected data file not found at {path}. "
            f"Run the dataset download step described in data/README.md first."
        )


def load_ratings(path: Path = RATINGS_FILE) -> pd.DataFrame:
    """
    Load ratings.dat into a DataFrame with columns:
    user_id (int64), movie_id (int64), rating (int64), timestamp (int64).
    """
    _validate_file_exists(path)
    df = pd.read_csv(
        path, sep="::", engine="python", names=RATINGS_COLUMNS, encoding="latin-1"
    )
    logger.info("Loaded ratings: %d rows from %s", len(df), path)
    return df


def load_movies(path: Path = MOVIES_FILE) -> pd.DataFrame:
    """
    Load movies.dat into a DataFrame with columns:
    movie_id (int64), title (str), genres (str, pipe-separated).
    """
    _validate_file_exists(path)
    df = pd.read_csv(
        path, sep="::", engine="python", names=MOVIES_COLUMNS, encoding="latin-1"
    )
    logger.info("Loaded movies: %d rows from %s", len(df), path)
    return df


def load_users(path: Path = USERS_FILE) -> pd.DataFrame:
    """
    Load users.dat into a DataFrame with columns:
    user_id (int64), gender (str), age (int64), occupation (int64),
    zip_code (str).
    """
    _validate_file_exists(path)
    df = pd.read_csv(
        path, sep="::", engine="python", names=USERS_COLUMNS, encoding="latin-1"
    )
    logger.info("Loaded users: %d rows from %s", len(df), path)
    return df


def load_all() -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Convenience function returning (ratings, movies, users) DataFrames."""
    return load_ratings(), load_movies(), load_users()


if __name__ == "__main__":
    ratings, movies, users = load_all()
    print(f"ratings: {ratings.shape}, movies: {movies.shape}, users: {users.shape}")
