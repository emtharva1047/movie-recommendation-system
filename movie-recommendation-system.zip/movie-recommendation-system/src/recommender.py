"""
recommender.py
---------------
Implements every recommendation algorithm required by the project:
Popularity Baseline, Content-Based Filtering, User-Based Collaborative
Filtering, Item-Based Collaborative Filtering, SVD Matrix Factorization,
and a Hybrid model combining them.

Each class exposes:
    fit(train_ratings, ...)              -> trains the model
    recommend(user_id, n=10, exclude_seen=True) -> list[(item_id, score)]

Keeping a single shared interface lets Phase 15 (model comparison) and
Phase 19 (Streamlit) call any model interchangeably.
"""

from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from src.logging_config import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# 1. Popularity Baseline
# ---------------------------------------------------------------------------
class PopularityRecommender:
    """
    Recommends the globally most-popular items, ranked by a Bayesian-averaged
    score that balances rating count and average rating.

    Why Bayesian average instead of raw avg_rating: an item with a single
    5-star rating would otherwise outrank an item with 3,000 ratings
    averaging 4.5 -- clearly wrong for a "popular" ranking. The Bayesian
    average pulls low-count items toward the global mean, which is the
    standard fix (same idea IMDB's "Top 250" formula uses).

    Strengths: works with zero personalization data (pure cold-start fallback).
    Weaknesses: identical recommendations for every user; ignores individual taste.
    """

    def __init__(self, min_ratings_prior: int = 20):
        self.min_ratings_prior = min_ratings_prior
        self.item_scores_: Optional[pd.DataFrame] = None
        self.global_mean_: Optional[float] = None

    def fit(self, train_ratings: pd.DataFrame) -> "PopularityRecommender":
        self.global_mean_ = train_ratings["rating"].mean()
        agg = train_ratings.groupby("movie_id").agg(
            avg_rating=("rating", "mean"), n_ratings=("rating", "count")
        )
        m = self.min_ratings_prior
        c = self.global_mean_
        agg["bayesian_score"] = (
            (agg["n_ratings"] / (agg["n_ratings"] + m)) * agg["avg_rating"]
            + (m / (agg["n_ratings"] + m)) * c
        )
        self.item_scores_ = agg.sort_values("bayesian_score", ascending=False)
        logger.info("PopularityRecommender fit on %d items", len(agg))
        return self

    def recommend(
        self, user_id: int, seen_items: Optional[set] = None, n: int = 10
    ) -> List[Tuple[int, float]]:
        seen_items = seen_items or set()
        candidates = self.item_scores_[~self.item_scores_.index.isin(seen_items)]
        top = candidates.head(n)
        return list(zip(top.index.tolist(), top["bayesian_score"].tolist()))


# ---------------------------------------------------------------------------
# 2. Content-Based Filtering (genre TF-IDF + cosine similarity)
# ---------------------------------------------------------------------------
class ContentBasedRecommender:
    """
    Represents each movie as a TF-IDF vector over its genre tokens, then
    recommends items most similar to what a given user has rated highly.

    Working principle: genres are treated as a "document" (space-joined
    genre tokens); TF-IDF down-weights genres that are common across the
    whole catalog (e.g. Drama) relative to rarer, more distinctive genres
    (e.g. Film-Noir), so similarity reflects distinctive taste, not just
    catalog-wide genre frequency.

    Advantages: no cold-start problem for new items (as long as genre
    metadata exists); recommendations are explainable ("similar genres to X").
    Disadvantages: cannot capture quality/taste signals beyond genre;
    over-recommends within a user's already-explored genres (filter bubble).
    Cold-start (new user): degrades to "no profile yet" -- needs at least
    one rated item to build a user profile vector.
    """

    def __init__(self):
        self.tfidf_matrix_ = None
        self.movie_ids_: List[int] = []
        self.movie_idx_: Dict[int, int] = {}
        self.similarity_matrix_ = None

    def fit(self, movies: pd.DataFrame) -> "ContentBasedRecommender":
        movies = movies.sort_values("movie_id").reset_index(drop=True)
        self.movie_ids_ = movies["movie_id"].tolist()
        self.movie_idx_ = {m: i for i, m in enumerate(self.movie_ids_)}

        genre_docs = movies["genres"].str.replace("|", " ", regex=False)
        vectorizer = TfidfVectorizer()
        self.tfidf_matrix_ = vectorizer.fit_transform(genre_docs)
        self.similarity_matrix_ = cosine_similarity(self.tfidf_matrix_)
        logger.info(
            "ContentBasedRecommender fit: TF-IDF shape %s, vocab size %d",
            self.tfidf_matrix_.shape, len(vectorizer.vocabulary_),
        )
        return self

    def similar_items(self, movie_id: int, n: int = 10) -> List[Tuple[int, float]]:
        if movie_id not in self.movie_idx_:
            return []
        idx = self.movie_idx_[movie_id]
        sims = self.similarity_matrix_[idx]
        order = np.argsort(-sims)
        results = []
        for i in order:
            if i == idx:
                continue
            results.append((self.movie_ids_[i], float(sims[i])))
            if len(results) >= n:
                break
        return results

    def recommend(
        self, user_ratings: pd.DataFrame, seen_items: Optional[set] = None, n: int = 10
    ) -> List[Tuple[int, float]]:
        """
        Build a user profile as the rating-weighted average TF-IDF vector of
        items they rated >= 4, then rank all unseen items by cosine
        similarity to that profile.
        """
        seen_items = seen_items or set(user_ratings["movie_id"])
        liked = user_ratings[user_ratings["rating"] >= 4]
        if liked.empty:
            return []

        liked_idxs = [self.movie_idx_[m] for m in liked["movie_id"] if m in self.movie_idx_]
        if not liked_idxs:
            return []
        weights = liked.set_index("movie_id").loc[
            [self.movie_ids_[i] for i in liked_idxs], "rating"
        ].values
        profile = np.asarray(
            self.tfidf_matrix_[liked_idxs].multiply(weights[:, None]).mean(axis=0)
        )
        scores = cosine_similarity(profile, self.tfidf_matrix_)[0]

        order = np.argsort(-scores)
        results = []
        for i in order:
            mid = self.movie_ids_[i]
            if mid in seen_items:
                continue
            results.append((mid, float(scores[i])))
            if len(results) >= n:
                break
        return results


# ---------------------------------------------------------------------------
# 3. User-Based Collaborative Filtering
# ---------------------------------------------------------------------------
class UserBasedCF:
    """
    Finds the K users most similar to the target user (cosine or Pearson
    similarity on mean-centered rating vectors) and recommends items those
    neighbors rated highly that the target user hasn't seen.

    Advantages: captures "people like you" signal, adapts to niche taste.
    Disadvantages: does not scale well (must compare target user to all
    other users at query time -- O(n_users) per recommendation);
    cold-start for new users (no ratings yet -> no neighbors to compare).
    Business suitability: strong for platforms with stable, engaged user
    bases; weaker for platforms with heavy new-user churn.
    """

    def __init__(self, k_neighbors: int = 30, similarity: str = "cosine"):
        self.k_neighbors = k_neighbors
        self.similarity = similarity
        self.matrix_: Optional[sparse.csr_matrix] = None
        self.user_ids_: List[int] = []
        self.item_ids_: List[int] = []
        self.user_idx_: Dict[int, int] = {}
        self.item_idx_: Dict[int, int] = {}
        self.user_means_: Optional[np.ndarray] = None
        self.sim_matrix_: Optional[np.ndarray] = None

    def fit(self, matrix: sparse.csr_matrix, user_ids: List[int], item_ids: List[int]):
        self.matrix_ = matrix
        self.user_ids_ = user_ids
        self.item_ids_ = item_ids
        self.user_idx_ = {u: i for i, u in enumerate(user_ids)}
        self.item_idx_ = {m: i for i, m in enumerate(item_ids)}

        dense_mask = matrix.copy()
        dense_mask.data = np.ones_like(dense_mask.data)
        row_sums = np.asarray(matrix.sum(axis=1)).flatten()
        row_counts = np.asarray(dense_mask.sum(axis=1)).flatten()
        row_counts[row_counts == 0] = 1
        self.user_means_ = row_sums / row_counts

        centered = matrix.copy().astype(np.float64)
        for i in range(centered.shape[0]):
            start, end = centered.indptr[i], centered.indptr[i + 1]
            centered.data[start:end] -= self.user_means_[i]

        # Pearson correlation on mean-centered vectors == cosine similarity
        # of the centered vectors. Using cosine on centered data implements
        # Pearson; using cosine on raw data implements standard cosine.
        base = centered if self.similarity == "pearson" else matrix.astype(np.float64)
        self.sim_matrix_ = cosine_similarity(base)
        np.fill_diagonal(self.sim_matrix_, 0.0)
        logger.info(
            "UserBasedCF fit: %d users, similarity=%s", len(user_ids), self.similarity
        )
        return self

    def recommend(self, user_id: int, n: int = 10) -> List[Tuple[int, float]]:
        if user_id not in self.user_idx_:
            return []
        u = self.user_idx_[user_id]
        sims = self.sim_matrix_[u]
        neighbor_order = np.argsort(-sims)[: self.k_neighbors]
        neighbor_sims = sims[neighbor_order]

        seen_cols = set(self.matrix_[u].indices)

        numerator = np.zeros(self.matrix_.shape[1])
        denominator = np.zeros(self.matrix_.shape[1])
        for neighbor_idx, sim in zip(neighbor_order, neighbor_sims):
            if sim <= 0:
                continue
            row = self.matrix_[neighbor_idx]
            numerator[row.indices] += sim * (row.data - self.user_means_[neighbor_idx])
            denominator[row.indices] += abs(sim)

        with np.errstate(divide="ignore", invalid="ignore"):
            pred = self.user_means_[u] + np.where(denominator > 0, numerator / denominator, 0)

        pred[list(seen_cols)] = -np.inf
        top_cols = np.argsort(-pred)[:n]
        return [(self.item_ids_[c], float(pred[c])) for c in top_cols if pred[c] > -np.inf]


# ---------------------------------------------------------------------------
# 4. Item-Based Collaborative Filtering
# ---------------------------------------------------------------------------
class ItemBasedCF:
    """
    Computes item-item cosine similarity on the (transposed) user-item
    matrix, then recommends items similar to what the target user has
    already rated highly.

    Advantages: item-item similarities are far more stable over time than
    user-user similarities (items don't change taste), and can be
    precomputed offline -- much better production scalability than
    user-based CF for large, slowly-changing catalogs.
    Disadvantages: cold-start for brand-new items with no ratings yet.
    Computational complexity: O(n_items^2) similarity computation, done
    once offline; O(k) per recommendation at query time -- this is exactly
    why Amazon-style "customers who bought this also bought" scales well.
    """

    def __init__(self, k_neighbors: int = 30):
        self.k_neighbors = k_neighbors
        self.matrix_: Optional[sparse.csr_matrix] = None
        self.item_ids_: List[int] = []
        self.item_idx_: Dict[int, int] = {}
        self.item_sim_: Optional[np.ndarray] = None

    def fit(self, matrix: sparse.csr_matrix, item_ids: List[int]):
        self.matrix_ = matrix
        self.item_ids_ = item_ids
        self.item_idx_ = {m: i for i, m in enumerate(item_ids)}
        item_matrix = matrix.T.tocsr()
        self.item_sim_ = cosine_similarity(item_matrix)
        np.fill_diagonal(self.item_sim_, 0.0)
        logger.info("ItemBasedCF fit: %d items", len(item_ids))
        return self

    def similar_items(self, movie_id: int, n: int = 10) -> List[Tuple[int, float]]:
        if movie_id not in self.item_idx_:
            return []
        idx = self.item_idx_[movie_id]
        sims = self.item_sim_[idx]
        order = np.argsort(-sims)[:n]
        return [(self.item_ids_[i], float(sims[i])) for i in order]

    def recommend(self, user_id: int, user_row_idx: int, n: int = 10) -> List[Tuple[int, float]]:
        row = self.matrix_[user_row_idx]
        seen_cols = set(row.indices)
        scores = np.zeros(self.matrix_.shape[1])
        for col, rating in zip(row.indices, row.data):
            scores += self.item_sim_[col] * rating
        scores[list(seen_cols)] = -np.inf
        top_cols = np.argsort(-scores)[:n]
        return [(self.item_ids_[c], float(scores[c])) for c in top_cols if scores[c] > -np.inf]


# ---------------------------------------------------------------------------
# 5. Hybrid Recommender
# ---------------------------------------------------------------------------
class HybridRecommender:
    """
    Combines Popularity, Content-Based, and SVD-based scores via a weighted
    linear blend. Weighted blending (rather than switching or cascading) is
    used because it lets each signal contribute proportionally to every
    recommendation rather than fully replacing the others, and is simple
    enough to reason about and tune with a single set of weights.

    Cold-start handling: when a user has too few ratings for CF/SVD to be
    reliable, the popularity weight is automatically increased (see
    `_effective_weights`).
    """

    def __init__(
        self,
        popularity_model: PopularityRecommender,
        content_model: ContentBasedRecommender,
        svd_predict_fn,
        weights: Dict[str, float] = None,
        cold_start_threshold: int = 5,
    ):
        self.popularity_model = popularity_model
        self.content_model = content_model
        self.svd_predict_fn = svd_predict_fn
        self.weights = weights or {"popularity": 0.2, "content": 0.3, "svd": 0.5}
        self.cold_start_threshold = cold_start_threshold

    def _effective_weights(self, n_user_ratings: int) -> Dict[str, float]:
        if n_user_ratings < self.cold_start_threshold:
            return {"popularity": 0.7, "content": 0.3, "svd": 0.0}
        return self.weights

    def recommend(
        self,
        user_id: int,
        user_ratings: pd.DataFrame,
        all_item_ids: List[int],
        n: int = 10,
    ) -> List[Tuple[int, float]]:
        seen = set(user_ratings["movie_id"])
        n_user_ratings = len(user_ratings)
        w = self._effective_weights(n_user_ratings)

        pop_scores = dict(
            self.popularity_model.recommend(user_id, seen_items=set(), n=len(all_item_ids))
        )
        max_pop = max(pop_scores.values()) if pop_scores else 1.0

        content_recs = (
            self.content_model.recommend(user_ratings, seen_items=set(), n=len(all_item_ids))
            if w["content"] > 0
            else []
        )
        content_scores = dict(content_recs)

        blended = {}
        for item_id in all_item_ids:
            if item_id in seen:
                continue
            pop_norm = pop_scores.get(item_id, 0.0) / max_pop if max_pop else 0.0
            content_norm = content_scores.get(item_id, 0.0)  # cosine already in [0,1]
            svd_norm = self.svd_predict_fn(user_id, item_id) / 5.0 if w["svd"] > 0 else 0.0
            blended[item_id] = (
                w["popularity"] * pop_norm + w["content"] * content_norm + w["svd"] * svd_norm
            )

        top = sorted(blended.items(), key=lambda x: -x[1])[:n]
        return top
