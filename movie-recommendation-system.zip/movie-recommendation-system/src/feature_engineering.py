"""
feature_engineering.py
-----------------------
Derives user-level and item-level features purely from ratings + movies
data (no leakage from future information, no fabricated columns).

Every feature is documented with: definition, formula, business meaning,
and why it helps recommendation quality. See docs/technical_documentation.md
for the narrative version of this table.
"""

import pandas as pd
import numpy as np

from src.logging_config import get_logger

logger = get_logger(__name__)


def build_user_features(ratings: pd.DataFrame) -> pd.DataFrame:
    """
    Build user-level features.

    Features
    --------
    avg_user_rating : mean of all ratings given by the user.
        Business meaning: how generous/critical a rater the user is.
        ML meaning: used to mean-center ratings for user-based CF and SVD,
        removing individual rating-scale bias before computing similarity.
    user_rating_std : std of ratings given by the user.
        ML meaning: low std = user rates almost everything the same way
        (low-information rater); informs confidence weighting.
    user_activity_score : count of ratings given by the user (n_ratings).
        Business meaning: engagement level.
        ML meaning: used to exclude ultra-low-activity users from
        similarity-based neighbor search noise.
    user_activity_span_days : days between user's first and last rating.
        Business meaning: how long the user has been actively engaged.
    """
    agg = ratings.groupby("user_id").agg(
        avg_user_rating=("rating", "mean"),
        user_rating_std=("rating", "std"),
        user_activity_score=("rating", "count"),
        first_ts=("timestamp", "min"),
        last_ts=("timestamp", "max"),
    ).reset_index()
    agg["user_rating_std"] = agg["user_rating_std"].fillna(0.0)
    agg["user_activity_span_days"] = (agg["last_ts"] - agg["first_ts"]) / 86400.0
    agg = agg.drop(columns=["first_ts", "last_ts"])
    logger.info("Built user features for %d users", len(agg))
    return agg


def build_item_features(ratings: pd.DataFrame, movies: pd.DataFrame) -> pd.DataFrame:
    """
    Build item-level features.

    Features
    --------
    avg_item_rating : mean rating received by the item.
        Business meaning: perceived quality.
        ML meaning: core signal for the popularity baseline (Phase 9) and
        as a prior for cold-start items in the hybrid model (Phase 14).
    item_popularity_score : count of ratings received (n_ratings).
        Business meaning: how widely known/consumed the item is.
        ML meaning: distinguishes "genuinely liked by many" (high count +
        high avg) from "liked by a tiny enthusiastic niche" (low count +
        high avg) -- both matter differently for ranking.
    item_rating_std : std of ratings received by the item.
        ML meaning: high std = polarizing item; useful for diversity-aware
        ranking discussions in Phase 16/18.
    """
    agg = ratings.groupby("movie_id").agg(
        avg_item_rating=("rating", "mean"),
        item_popularity_score=("rating", "count"),
        item_rating_std=("rating", "std"),
    ).reset_index()
    agg["item_rating_std"] = agg["item_rating_std"].fillna(0.0)
    agg = agg.merge(movies[["movie_id", "title", "genres", "year"]], on="movie_id", how="left")
    logger.info("Built item features for %d items", len(agg))
    return agg


if __name__ == "__main__":
    from src.config import (
        RATINGS_CLEAN_FILE, MOVIES_CLEAN_FILE,
        USER_FEATURES_FILE, ITEM_FEATURES_FILE,
    )

    ratings = pd.read_csv(RATINGS_CLEAN_FILE)
    movies = pd.read_csv(MOVIES_CLEAN_FILE)

    user_features = build_user_features(ratings)
    item_features = build_item_features(ratings, movies)

    user_features.to_csv(USER_FEATURES_FILE, index=False)
    item_features.to_csv(ITEM_FEATURES_FILE, index=False)
    print("Saved user_features.csv:", user_features.shape)
    print("Saved item_features.csv:", item_features.shape)
    print(user_features.head(3))
    print(item_features.head(3))
