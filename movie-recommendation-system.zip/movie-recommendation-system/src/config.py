"""
config.py
---------
Central configuration for the Recommendation System project.

This module is the SINGLE SOURCE OF TRUTH for file paths, random seeds,
and model hyperparameters. Every other module and notebook imports from
here instead of hard-coding values, so that changing a path or a seed
in one place propagates consistently across the whole project.
"""

from pathlib import Path

# ---------------------------------------------------------------------------
# Project root and directory layout
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATA_RAW_DIR = PROJECT_ROOT / "data" / "raw"
DATA_PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
MODELS_DIR = PROJECT_ROOT / "models" / "trained_models"
FIGURES_DIR = PROJECT_ROOT / "figures"
LOGS_DIR = PROJECT_ROOT / "logs"

for _dir in (DATA_PROCESSED_DIR, MODELS_DIR, FIGURES_DIR, LOGS_DIR):
    _dir.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Raw data files
# ---------------------------------------------------------------------------
RATINGS_FILE = DATA_RAW_DIR / "ratings.dat"
MOVIES_FILE = DATA_RAW_DIR / "movies.dat"
USERS_FILE = DATA_RAW_DIR / "users.dat"

# ---------------------------------------------------------------------------
# Processed data files
# ---------------------------------------------------------------------------
RATINGS_CLEAN_FILE = DATA_PROCESSED_DIR / "ratings_clean.csv"
MOVIES_CLEAN_FILE = DATA_PROCESSED_DIR / "movies_clean.csv"
USERS_CLEAN_FILE = DATA_PROCESSED_DIR / "users_clean.csv"
USER_FEATURES_FILE = DATA_PROCESSED_DIR / "user_features.csv"
ITEM_FEATURES_FILE = DATA_PROCESSED_DIR / "item_features.csv"
TRAIN_RATINGS_FILE = DATA_PROCESSED_DIR / "train_ratings.csv"
TEST_RATINGS_FILE = DATA_PROCESSED_DIR / "test_ratings.csv"

# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------
RANDOM_SEED = 42

# ---------------------------------------------------------------------------
# Data cleaning thresholds (justified in docs/technical_documentation.md
# and reports/recommendation_system_report — never change silently, any
# change here must be re-justified in both places)
# ---------------------------------------------------------------------------
MIN_RATINGS_PER_USER = 20   # matches official ML-1M collection design (all
                             # users already have >=20 ratings; kept as an
                             # explicit, auditable guard rather than assumed)
MIN_RATINGS_PER_ITEM = 5    # remove near-zero-signal items that cannot
                             # support reliable similarity computation

# ---------------------------------------------------------------------------
# Train/test split
# ---------------------------------------------------------------------------
TEST_SIZE = 0.2             # fraction of each user's ratings held out
SPLIT_STRATEGY = "temporal_per_user"  # see Phase 16 justification

# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------
TOP_K = 10                  # K used for Precision@K / Recall@K / MAP@K / NDCG@K
RELEVANCE_THRESHOLD = 4     # rating >= 4 counted as "relevant" for ranking metrics

# ---------------------------------------------------------------------------
# Matrix Factorization (SVD) hyperparameters
# ---------------------------------------------------------------------------
SVD_N_FACTORS = 100
SVD_N_EPOCHS = 20
SVD_LR_ALL = 0.005
SVD_REG_ALL = 0.02

# ---------------------------------------------------------------------------
# Collaborative filtering
# ---------------------------------------------------------------------------
CF_TOP_N_NEIGHBORS = 30

# ---------------------------------------------------------------------------
# Content-based filtering
# ---------------------------------------------------------------------------
TFIDF_MAX_FEATURES = None   # use full genre vocabulary (small, ~18 genres)
