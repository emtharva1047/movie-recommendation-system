"""
app.py
------
Streamlit application for the MovieLens 1M Recommendation System.

Run with: streamlit run app.py
"""

import pickle
import sys
from pathlib import Path

import pandas as pd
import numpy as np
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.config import (
    MOVIES_CLEAN_FILE, TRAIN_RATINGS_FILE, MODELS_DIR,
)

st.set_page_config(
    page_title="MovieLens Recommendation System",
    page_icon="🎬",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Cached data / model loading
# ---------------------------------------------------------------------------
@st.cache_data
def load_data():
    movies = pd.read_csv(MOVIES_CLEAN_FILE)
    ratings = pd.read_csv(TRAIN_RATINGS_FILE)
    return movies, ratings


@st.cache_resource
def load_models():
    models = {}
    try:
        with open(MODELS_DIR / "item_based_cf_model.pkl", "rb") as f:
            models["item_based_cf"] = pickle.load(f)
    except FileNotFoundError:
        models["item_based_cf"] = None
    try:
        with open(MODELS_DIR / "popularity_model.pkl", "rb") as f:
            models["popularity"] = pickle.load(f)
    except FileNotFoundError:
        models["popularity"] = None
    try:
        with open(MODELS_DIR / "content_based_model.pkl", "rb") as f:
            models["content_based"] = pickle.load(f)
    except FileNotFoundError:
        models["content_based"] = None
    try:
        with open(MODELS_DIR / "svd_model.pkl", "rb") as f:
            models["svd"] = pickle.load(f)
    except FileNotFoundError:
        models["svd"] = None
    try:
        with open(Path("data/processed/train_id_mappings.pkl"), "rb") as f:
            models["mappings"] = pickle.load(f)
    except FileNotFoundError:
        models["mappings"] = None
    return models


@st.cache_data
def load_metrics():
    import json
    try:
        with open("reports/model_comparison_final.json") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}


movies_df, ratings_df = load_data()
models = load_models()
metrics = load_metrics()
movies_lookup = movies_df.set_index("movie_id")["title"]


# ---------------------------------------------------------------------------
# Sidebar navigation
# ---------------------------------------------------------------------------
st.sidebar.title("🎬 MovieLens Recommender")
page = st.sidebar.radio(
    "Navigate",
    ["Home / Dashboard", "Get Recommendations", "Similar Movies", "Search Movies", "Model Comparison"],
)

st.sidebar.markdown("---")
st.sidebar.caption("Dataset: MovieLens 1M (GroupLens Research)")
st.sidebar.caption(f"{len(ratings_df):,} ratings \u00b7 {ratings_df.user_id.nunique():,} users \u00b7 {ratings_df.movie_id.nunique():,} movies (training split)")


# ---------------------------------------------------------------------------
# HOME / DASHBOARD
# ---------------------------------------------------------------------------
if page == "Home / Dashboard":
    st.title("🎬 Movie Recommendation System")
    st.markdown(
        "A production-style recommendation system built on the **MovieLens 1M** dataset, "
        "implementing and comparing Popularity, Content-Based, User-Based CF, Item-Based CF, "
        "SVD Matrix Factorization, and Hybrid recommendation algorithms."
    )

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Training Ratings", f"{len(ratings_df):,}")
    col2.metric("Users", f"{ratings_df.user_id.nunique():,}")
    col3.metric("Movies", f"{ratings_df.movie_id.nunique():,}")
    _sparsity = 1 - len(ratings_df) / (ratings_df.user_id.nunique() * ratings_df.movie_id.nunique())
    col4.metric("Matrix Sparsity (train)", f"{_sparsity*100:.2f}%")

    st.subheader("Selected Model: Item-Based Collaborative Filtering")
    st.markdown(
        "Chosen because it achieved the best ranking-quality metrics of every algorithm "
        "implemented in this project, evaluated on an identical held-out test sample."
    )

    if metrics:
        rows = []
        for name, d in metrics.items():
            rows.append({
                "Model": name,
                "Precision@10": round(d.get("precision_at_k", 0), 4),
                "Recall@10": round(d.get("recall_at_k", 0), 4),
                "MAP@10": round(d.get("map_at_k", 0), 4),
                "NDCG@10": round(d.get("ndcg_at_k", 0), 4),
            })
        comparison_df = pd.DataFrame(rows).sort_values("Precision@10", ascending=False)
        st.dataframe(comparison_df, use_container_width=True, hide_index=True)
    else:
        st.info("Model comparison metrics not found — run the evaluation scripts first.")

    st.subheader("Genre Distribution in Catalog")
    genre_counts = {}
    for g in movies_df["genres"]:
        for genre in g.split("|"):
            genre_counts[genre] = genre_counts.get(genre, 0) + 1
    genre_series = pd.Series(genre_counts).sort_values(ascending=False)
    st.bar_chart(genre_series)


# ---------------------------------------------------------------------------
# GET RECOMMENDATIONS
# ---------------------------------------------------------------------------
elif page == "Get Recommendations":
    st.title("Get Personalized Recommendations")

    all_user_ids = sorted(ratings_df["user_id"].unique().tolist())

    input_mode = st.radio("Select user by:", ["Pick from list", "Enter User ID"], horizontal=True)
    if input_mode == "Pick from list":
        user_id = st.selectbox("Select a User", all_user_ids)
    else:
        user_id = st.number_input(
            "Enter User ID", min_value=int(min(all_user_ids)),
            max_value=int(max(all_user_ids)), value=int(all_user_ids[0]), step=1,
        )

    n_recs = st.slider("Number of recommendations", 5, 20, 10)

    model_choice = st.selectbox(
        "Recommendation Method",
        ["Item-Based Collaborative Filtering (recommended — best evaluated accuracy)",
         "Popularity Baseline"],
    )

    if st.button("Generate Recommendations", type="primary"):
        if user_id not in ratings_df["user_id"].unique():
            st.error(
                f"User {user_id} was not found in the training data. "
                f"Please choose a valid user ID between {min(all_user_ids)} and {max(all_user_ids)}."
            )
        else:
            user_history = ratings_df[ratings_df.user_id == user_id].merge(
                movies_df[["movie_id", "title"]], on="movie_id"
            ).sort_values("rating", ascending=False)

            st.subheader(f"User {user_id}'s Rating History (top rated)")
            st.dataframe(
                user_history[["title", "rating"]].head(10), use_container_width=True, hide_index=True
            )

            recs = []
            method_used = ""
            try:
                if model_choice.startswith("Item-Based") and models["item_based_cf"] and models["mappings"]:
                    user_to_idx = models["mappings"]["user_to_idx"]
                    if user_id in user_to_idx:
                        recs = models["item_based_cf"].recommend(user_id, user_to_idx[user_id], n=n_recs)
                        method_used = "Item-Based Collaborative Filtering"
                    else:
                        st.warning("User not in the collaborative-filtering index — falling back to Popularity.")
                        seen = set(user_history["movie_id"])
                        recs = models["popularity"].recommend(user_id, seen_items=seen, n=n_recs)
                        method_used = "Popularity Baseline (fallback)"
                else:
                    seen = set(user_history["movie_id"])
                    recs = models["popularity"].recommend(user_id, seen_items=seen, n=n_recs)
                    method_used = "Popularity Baseline"
            except Exception as e:
                st.error(f"Recommendation generation failed: {e}")
                recs = []

            if not recs:
                st.warning("No recommendations could be generated for this user with the selected method.")
            else:
                st.subheader(f"Top {len(recs)} Recommendations — {method_used}")
                rec_rows = []
                for rank, (mid, score) in enumerate(recs, start=1):
                    title = movies_lookup.get(mid, f"Unknown (movie_id={mid})")
                    rec_rows.append({"Rank": rank, "Title": title, "Movie ID": int(mid), "Score": round(float(score), 4)})
                rec_df = pd.DataFrame(rec_rows)
                st.dataframe(rec_df, use_container_width=True, hide_index=True)

                csv = rec_df.to_csv(index=False).encode("utf-8")
                st.download_button(
                    "Download Recommendations as CSV", csv,
                    file_name=f"recommendations_user_{user_id}.csv", mime="text/csv",
                )


# ---------------------------------------------------------------------------
# SIMILAR MOVIES
# ---------------------------------------------------------------------------
elif page == "Similar Movies":
    st.title("Find Similar Movies")
    st.markdown("Uses Item-Based Collaborative Filtering similarity (computed from co-rating patterns).")

    movie_titles = movies_df.sort_values("title")["title"].tolist()
    selected_title = st.selectbox("Select a movie", movie_titles)
    n_similar = st.slider("Number of similar movies", 5, 20, 10)

    if st.button("Find Similar Movies", type="primary"):
        try:
            movie_id = movies_df[movies_df.title == selected_title]["movie_id"].iloc[0]
            if models["item_based_cf"] is None:
                st.error("Item-based CF model file not found — cannot compute similarity.")
            else:
                similar = models["item_based_cf"].similar_items(int(movie_id), n=n_similar)
                if not similar:
                    st.warning(
                        "This movie has too few ratings in the training set to compute reliable similarities."
                    )
                else:
                    rows = [
                        {"Rank": i, "Title": movies_lookup.get(mid, "Unknown"), "Similarity Score": round(score, 4)}
                        for i, (mid, score) in enumerate(similar, start=1)
                    ]
                    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        except IndexError:
            st.error("Selected movie could not be found in the catalog.")
        except Exception as e:
            st.error(f"An error occurred: {e}")


# ---------------------------------------------------------------------------
# SEARCH MOVIES
# ---------------------------------------------------------------------------
elif page == "Search Movies":
    st.title("Search the Movie Catalog")
    query = st.text_input("Search by title keyword")
    genre_filter = st.multiselect(
        "Filter by genre",
        sorted({g for genres in movies_df["genres"] for g in genres.split("|")}),
    )

    filtered = movies_df.copy()
    if query:
        filtered = filtered[filtered["title"].str.contains(query, case=False, na=False)]
    if genre_filter:
        filtered = filtered[
            filtered["genres"].apply(lambda g: any(genre in g.split("|") for genre in genre_filter))
        ]

    if filtered.empty:
        st.info("No movies match your search criteria. Try a different keyword or genre.")
    else:
        st.write(f"Found {len(filtered)} movies")
        st.dataframe(filtered[["movie_id", "title", "genres", "year"]], use_container_width=True, hide_index=True)


# ---------------------------------------------------------------------------
# MODEL COMPARISON
# ---------------------------------------------------------------------------
elif page == "Model Comparison":
    st.title("Model Comparison — Evaluated on Identical Held-Out Data")
    if not metrics:
        st.info("Model comparison metrics not found.")
    else:
        rows = []
        for name, d in metrics.items():
            rows.append({
                "Model": name,
                "Precision@10": round(d.get("precision_at_k", 0), 4),
                "Recall@10": round(d.get("recall_at_k", 0), 4),
                "MAP@10": round(d.get("map_at_k", 0), 4),
                "NDCG@10": round(d.get("ndcg_at_k", 0), 4),
                "RMSE": round(d["rmse"], 4) if "rmse" in d else "-",
                "MAE": round(d["mae"], 4) if "mae" in d else "-",
            })
        comparison_df = pd.DataFrame(rows).sort_values("Precision@10", ascending=False)
        st.dataframe(comparison_df, use_container_width=True, hide_index=True)
        st.bar_chart(comparison_df.set_index("Model")["Precision@10"])

        st.markdown(
            "**Final model selected: Item-Based Collaborative Filtering** — best ranking "
            "accuracy across every metric on an identical 1,500-user held-out evaluation sample. "
            "See `reports/business_insights.md` and the project report for the full trade-off discussion "
            "(SVD offers substantially higher catalog coverage/diversity at the cost of ranking precision)."
        )
