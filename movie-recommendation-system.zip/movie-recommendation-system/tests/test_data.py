"""
test_data.py
------------
Tests for data loading and preprocessing.
"""

import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.data_loader import load_ratings, load_movies, load_users, load_all
from src.preprocessing import clean_ratings, clean_movies, clean_users, run_cleaning_pipeline


class TestDataLoader:
    def test_load_ratings_shape_and_columns(self):
        ratings = load_ratings()
        assert list(ratings.columns) == ["user_id", "movie_id", "rating", "timestamp"]
        assert len(ratings) == 1_000_209

    def test_load_movies_shape_and_columns(self):
        movies = load_movies()
        assert list(movies.columns) == ["movie_id", "title", "genres"]
        assert len(movies) == 3883

    def test_load_users_shape_and_columns(self):
        users = load_users()
        assert list(users.columns) == ["user_id", "gender", "age", "occupation", "zip_code"]
        assert len(users) == 6040

    def test_load_all_returns_three_dataframes(self):
        ratings, movies, users = load_all()
        assert isinstance(ratings, pd.DataFrame)
        assert isinstance(movies, pd.DataFrame)
        assert isinstance(users, pd.DataFrame)

    def test_ratings_values_in_valid_range(self):
        ratings = load_ratings()
        assert ratings["rating"].isin([1, 2, 3, 4, 5]).all()

    def test_load_ratings_missing_file_raises(self, tmp_path):
        fake_path = tmp_path / "does_not_exist.dat"
        with pytest.raises(FileNotFoundError):
            load_ratings(path=fake_path)


class TestPreprocessing:
    def test_clean_ratings_removes_low_signal_items(self):
        ratings = load_ratings()
        cleaned = clean_ratings(ratings)
        item_counts = cleaned.groupby("movie_id").size()
        assert (item_counts >= 5).all()

    def test_clean_ratings_no_duplicates(self):
        ratings = load_ratings()
        cleaned = clean_ratings(ratings)
        assert cleaned.duplicated().sum() == 0

    def test_clean_movies_adds_year_column(self):
        movies = load_movies()
        cleaned = clean_movies(movies)
        assert "year" in cleaned.columns
        assert cleaned["year"].notnull().sum() > 0

    def test_clean_users_adds_labels(self):
        users = load_users()
        cleaned = clean_users(users)
        assert "age_label" in cleaned.columns
        assert "occupation_label" in cleaned.columns
        assert cleaned["age_label"].notnull().all()

    def test_full_pipeline_consistency(self):
        ratings, movies, users = load_all()
        r_clean, m_clean, u_clean = run_cleaning_pipeline(ratings, movies, users)
        # Every movie_id in cleaned ratings must exist in cleaned movies
        assert set(r_clean["movie_id"]).issubset(set(m_clean["movie_id"]))
        # Every user_id in cleaned ratings must exist in cleaned users
        assert set(r_clean["user_id"]).issubset(set(u_clean["user_id"]))
        assert len(r_clean) > 0
