"""
test_recommender.py
--------------------
Tests for all recommendation algorithms, including edge cases
(unknown users, unknown items, empty inputs).
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from scipy import sparse

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.recommender import (
    PopularityRecommender, ContentBasedRecommender, UserBasedCF, ItemBasedCF,
)


@pytest.fixture
def toy_ratings():
    """A small, hand-constructed ratings DataFrame for fast, deterministic tests."""
    data = {
        "user_id": [1, 1, 1, 2, 2, 3, 3, 3, 4, 4],
        "movie_id": [10, 20, 30, 10, 20, 10, 30, 40, 20, 40],
        "rating": [5, 4, 3, 5, 5, 4, 5, 2, 3, 4],
        "timestamp": [100, 101, 102, 103, 104, 105, 106, 107, 108, 109],
    }
    return pd.DataFrame(data)


@pytest.fixture
def toy_movies():
    return pd.DataFrame({
        "movie_id": [10, 20, 30, 40],
        "title": ["Movie A (2000)", "Movie B (2001)", "Movie C (2002)", "Movie D (2003)"],
        "genres": ["Action|Comedy", "Comedy|Romance", "Action|Thriller", "Romance|Drama"],
    })


@pytest.fixture
def toy_matrix(toy_ratings):
    user_ids = sorted(toy_ratings.user_id.unique())
    item_ids = sorted(toy_ratings.movie_id.unique())
    user_to_idx = {u: i for i, u in enumerate(user_ids)}
    item_to_idx = {m: i for i, m in enumerate(item_ids)}
    row = toy_ratings.user_id.map(user_to_idx).values
    col = toy_ratings.movie_id.map(item_to_idx).values
    data = toy_ratings.rating.values.astype(np.float32)
    matrix = sparse.csr_matrix((data, (row, col)), shape=(len(user_ids), len(item_ids)))
    return matrix, user_ids, item_ids


class TestPopularityRecommender:
    def test_fit_and_recommend_basic(self, toy_ratings):
        model = PopularityRecommender(min_ratings_prior=2)
        model.fit(toy_ratings)
        recs = model.recommend(user_id=1, seen_items=set(), n=3)
        assert len(recs) == 3
        assert all(isinstance(r, tuple) for r in recs)

    def test_recommend_excludes_seen_items(self, toy_ratings):
        model = PopularityRecommender(min_ratings_prior=2)
        model.fit(toy_ratings)
        recs = model.recommend(user_id=1, seen_items={10, 20, 30}, n=5)
        recommended_ids = [item for item, score in recs]
        assert 10 not in recommended_ids
        assert 20 not in recommended_ids
        assert 30 not in recommended_ids

    def test_recommend_for_unknown_user_still_returns_global_popularity(self, toy_ratings):
        # Popularity is user-agnostic by design -- should not crash for an
        # unknown user id, since it ignores the user id entirely.
        model = PopularityRecommender(min_ratings_prior=2)
        model.fit(toy_ratings)
        recs = model.recommend(user_id=9999, seen_items=set(), n=2)
        assert len(recs) == 2


class TestContentBasedRecommender:
    def test_fit_builds_similarity_matrix(self, toy_movies):
        model = ContentBasedRecommender()
        model.fit(toy_movies)
        assert model.similarity_matrix_.shape == (4, 4)

    def test_similar_items_excludes_self(self, toy_movies):
        model = ContentBasedRecommender()
        model.fit(toy_movies)
        sims = model.similar_items(10, n=3)
        similar_ids = [item for item, score in sims]
        assert 10 not in similar_ids

    def test_similar_items_unknown_movie_returns_empty(self, toy_movies):
        model = ContentBasedRecommender()
        model.fit(toy_movies)
        assert model.similar_items(99999, n=3) == []

    def test_recommend_with_no_liked_items_returns_empty(self, toy_movies):
        model = ContentBasedRecommender()
        model.fit(toy_movies)
        low_ratings = pd.DataFrame({"user_id": [1, 1], "movie_id": [10, 20], "rating": [2, 1]})
        recs = model.recommend(low_ratings, seen_items={10, 20}, n=3)
        assert recs == []


class TestUserBasedCF:
    def test_fit_and_recommend(self, toy_matrix):
        matrix, user_ids, item_ids = toy_matrix
        model = UserBasedCF(k_neighbors=2, similarity="cosine")
        model.fit(matrix, user_ids, item_ids)
        recs = model.recommend(user_id=1, n=2)
        assert isinstance(recs, list)

    def test_recommend_unknown_user_returns_empty(self, toy_matrix):
        matrix, user_ids, item_ids = toy_matrix
        model = UserBasedCF(k_neighbors=2)
        model.fit(matrix, user_ids, item_ids)
        assert model.recommend(user_id=99999, n=3) == []

    def test_pearson_similarity_mode_runs(self, toy_matrix):
        matrix, user_ids, item_ids = toy_matrix
        model = UserBasedCF(k_neighbors=2, similarity="pearson")
        model.fit(matrix, user_ids, item_ids)
        recs = model.recommend(user_id=2, n=2)
        assert isinstance(recs, list)


class TestItemBasedCF:
    def test_fit_and_similar_items(self, toy_matrix):
        matrix, user_ids, item_ids = toy_matrix
        model = ItemBasedCF(k_neighbors=2)
        model.fit(matrix, item_ids)
        sims = model.similar_items(10, n=2)
        assert isinstance(sims, list)

    def test_similar_items_unknown_item_returns_empty(self, toy_matrix):
        matrix, user_ids, item_ids = toy_matrix
        model = ItemBasedCF(k_neighbors=2)
        model.fit(matrix, item_ids)
        assert model.similar_items(99999, n=3) == []

    def test_recommend_excludes_seen_items(self, toy_matrix):
        matrix, user_ids, item_ids = toy_matrix
        model = ItemBasedCF(k_neighbors=2)
        model.fit(matrix, item_ids)
        recs = model.recommend(user_id=1, user_row_idx=0, n=5)
        recommended_ids = [item for item, score in recs]
        seen = set(item_ids[i] for i in matrix[0].indices)
        assert not (set(recommended_ids) & seen)
