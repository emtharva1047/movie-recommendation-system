"""
test_config_and_invariants.py
-------------------------------
Sanity tests for the central configuration and for cross-cutting data
invariants that every downstream phase depends on (e.g. the cleaned
dataset must simultaneously satisfy both filtering thresholds).
"""

import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import config


class TestConfig:
    def test_directories_exist(self):
        assert config.DATA_PROCESSED_DIR.exists()
        assert config.MODELS_DIR.exists()
        assert config.FIGURES_DIR.exists()

    def test_random_seed_is_fixed_int(self):
        assert isinstance(config.RANDOM_SEED, int)

    def test_thresholds_are_positive(self):
        assert config.MIN_RATINGS_PER_USER > 0
        assert config.MIN_RATINGS_PER_ITEM > 0

    def test_test_size_in_valid_range(self):
        assert 0 < config.TEST_SIZE < 1

    def test_top_k_positive(self):
        assert config.TOP_K > 0

    def test_relevance_threshold_within_rating_scale(self):
        assert 1 <= config.RELEVANCE_THRESHOLD <= 5


class TestCleanedDataInvariants:
    """
    These tests read the actual processed CSVs on disk (not synthetic data)
    to catch the exact class of bug found during Phase 21 development: a
    single-pass filter that does not guarantee both thresholds hold
    simultaneously after cascading removals.
    """

    @pytest.fixture
    def ratings_clean(self):
        path = config.RATINGS_CLEAN_FILE
        if not path.exists():
            pytest.skip("ratings_clean.csv not yet generated")
        return pd.read_csv(path)

    def test_all_items_meet_minimum_rating_count(self, ratings_clean):
        item_counts = ratings_clean.groupby("movie_id").size()
        assert (item_counts >= config.MIN_RATINGS_PER_ITEM).all()

    def test_all_users_meet_minimum_rating_count(self, ratings_clean):
        user_counts = ratings_clean.groupby("user_id").size()
        assert (user_counts >= config.MIN_RATINGS_PER_USER).all()

    def test_no_nulls_in_cleaned_ratings(self, ratings_clean):
        assert ratings_clean.isnull().sum().sum() == 0

    def test_no_duplicates_in_cleaned_ratings(self, ratings_clean):
        assert ratings_clean.duplicated().sum() == 0
