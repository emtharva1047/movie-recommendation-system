"""
test_evaluation.py
-------------------
Tests for ranking metrics, prediction metrics, and system-level metrics,
using hand-computable examples so expected values can be verified by hand.
"""

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.evaluation import (
    precision_at_k, recall_at_k, average_precision_at_k, ndcg_at_k,
    rmse, mae, catalog_coverage,
)


class TestRankingMetrics:
    def test_precision_at_k_all_relevant(self):
        recommended = [1, 2, 3]
        relevant = {1, 2, 3}
        assert precision_at_k(recommended, relevant, k=3) == 1.0

    def test_precision_at_k_none_relevant(self):
        recommended = [1, 2, 3]
        relevant = {4, 5, 6}
        assert precision_at_k(recommended, relevant, k=3) == 0.0

    def test_precision_at_k_partial(self):
        recommended = [1, 2, 3, 4]
        relevant = {1, 3}
        # top 4: hits = 2 (items 1 and 3) -> precision = 2/4
        assert precision_at_k(recommended, relevant, k=4) == 0.5

    def test_recall_at_k_all_found(self):
        recommended = [1, 2, 3]
        relevant = {1, 2}
        assert recall_at_k(recommended, relevant, k=3) == 1.0

    def test_recall_at_k_empty_relevant_returns_zero(self):
        assert recall_at_k([1, 2, 3], set(), k=3) == 0.0

    def test_average_precision_at_k_hand_computed(self):
        # relevant items at positions 1 and 3 (1-indexed) out of 3 recommended
        recommended = [1, 2, 3]
        relevant = {1, 3}
        # precision at hit 1 (pos 1) = 1/1 = 1.0
        # precision at hit 2 (pos 3) = 2/3
        # AP = (1.0 + 2/3) / min(2,3) = (1.6667)/2 = 0.8333
        result = average_precision_at_k(recommended, relevant, k=3)
        assert abs(result - 0.8333333) < 1e-4

    def test_ndcg_at_k_perfect_ranking_equals_one(self):
        recommended = [1, 2, 3]
        relevant = {1, 2, 3}
        result = ndcg_at_k(recommended, relevant, k=3)
        assert abs(result - 1.0) < 1e-9

    def test_ndcg_at_k_no_relevant_items_returns_zero(self):
        assert ndcg_at_k([1, 2, 3], set(), k=3) == 0.0

    def test_ndcg_at_k_worse_ranking_scores_lower_than_perfect(self):
        relevant = {3}
        perfect = ndcg_at_k([3, 1, 2], relevant, k=3)
        worse = ndcg_at_k([1, 2, 3], relevant, k=3)
        assert perfect > worse


class TestPredictionMetrics:
    def test_rmse_zero_for_perfect_predictions(self):
        y_true = [4, 3, 5]
        y_pred = [4, 3, 5]
        assert rmse(y_true, y_pred) == 0.0

    def test_rmse_hand_computed(self):
        y_true = [3, 3]
        y_pred = [4, 2]
        # errors: 1, -1 -> squared: 1, 1 -> mean 1 -> sqrt(1) = 1.0
        assert rmse(y_true, y_pred) == 1.0

    def test_mae_hand_computed(self):
        y_true = [3, 3]
        y_pred = [5, 1]
        # abs errors: 2, 2 -> mean = 2.0
        assert mae(y_true, y_pred) == 2.0


class TestSystemMetrics:
    def test_catalog_coverage_full(self):
        recommended = {1, 2, 3}
        assert catalog_coverage(recommended, total_catalog_size=3) == 1.0

    def test_catalog_coverage_partial(self):
        recommended = {1}
        assert catalog_coverage(recommended, total_catalog_size=4) == 0.25

    def test_catalog_coverage_empty_catalog_returns_zero(self):
        assert catalog_coverage(set(), total_catalog_size=0) == 0.0


class TestEvaluateModelIntegration:
    """Integration-style tests for evaluate_model against a hand-built test set."""

    def test_evaluate_model_perfect_recommender(self):
        from src.evaluation import evaluate_model
        import pandas as pd

        test_df = pd.DataFrame({
            "user_id": [1, 1, 2, 2],
            "movie_id": [10, 20, 30, 40],
            "rating": [5, 4, 5, 5],
        })

        def perfect_fn(user_id):
            return test_df[test_df.user_id == user_id]["movie_id"].tolist()

        result = evaluate_model(perfect_fn, test_df, relevance_threshold=4, k=2, user_sample=[1, 2])
        assert result["precision_at_k"] == 1.0
        assert result["n_users_evaluated"] == 2

    def test_evaluate_model_handles_none_recommendations(self):
        from src.evaluation import evaluate_model
        import pandas as pd

        test_df = pd.DataFrame({"user_id": [1], "movie_id": [10], "rating": [5]})

        def none_fn(user_id):
            return None

        result = evaluate_model(none_fn, test_df, relevance_threshold=4, k=5, user_sample=[1])
        assert result["n_users_evaluated"] == 0
        assert result["precision_at_k"] == 0.0

    def test_evaluate_model_empty_test_set(self):
        from src.evaluation import evaluate_model
        import pandas as pd

        empty_test = pd.DataFrame(columns=["user_id", "movie_id", "rating"])

        def any_fn(user_id):
            return [1, 2, 3]

        result = evaluate_model(any_fn, empty_test, relevance_threshold=4, k=5, user_sample=[1])
        assert result["n_users_evaluated"] == 0
